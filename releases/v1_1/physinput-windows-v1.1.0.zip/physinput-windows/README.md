# PhysInput for Windows

Physics-based analog input converter - transforms keyboard/mouse into smooth gamepad output.

## ⚠️ Anti-Cheat Notice

PhysInput creates a virtual gamepad. Some anti-cheat software may block virtual devices.
Intended for accessibility and single-player games.

## Installation

### Step 1: Install ViGEmBus Driver (Required)

Download and install from:
https://github.com/ViGEm/ViGEmBus/releases

Run `ViGEmBus_Setup_x64.msi`

### Step 2: Install Python Dependencies

```powershell
pip install pynput vgamepad PyQt6
```

### Step 3: Install PhysInput

```powershell
pip install -e .
```

### Step 4: Run

```powershell
physinput
```

## Requirements

- Windows 10/11
- Python 3.10+
- ViGEmBus driver
- pynput (input capture)
- vgamepad (virtual gamepad)
- PyQt6 (GUI)

## Features

- 9 physics models (spring, critical, momentum, fluid, etc.)
- Mouse to right stick with velocity mapping
- Full button binding
- Profile system
- Real-time visualization
- Xbox 360 or DualShock 4 emulation

## Usage

```powershell
physinput           # Start GUI
physinput --check   # Check system requirements
physinput --profile "fps"  # Load a profile
```

## License

MIT License
