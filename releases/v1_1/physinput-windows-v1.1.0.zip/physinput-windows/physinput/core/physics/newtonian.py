"""
Newtonian physics model.
Simulates acceleration and friction for momentum-based movement.
"""

import math
from typing import Tuple, Dict, Any

from .base import PhysicsModel


class NewtonianModel(PhysicsModel):
    """
    Newtonian physics with acceleration and friction.
    
    F = ma (acceleration towards target)
    Friction opposes velocity
    
    Good for: Weighty, momentum-based feel like driving a vehicle
    """
    
    name = "newtonian"
    description = "Acceleration and friction for momentum-based movement"
    
    @property
    def default_params(self) -> Dict[str, Any]:
        return {
            "acceleration": 15.0,    # How fast velocity builds
            "friction": 8.0,         # How fast velocity decays
            "max_velocity": 3.0,     # Maximum velocity magnitude
        }
    
    @property
    def param_ranges(self) -> Dict[str, Tuple[float, float, float]]:
        return {
            "acceleration": (1.0, 50.0, 0.5),
            "friction": (0.0, 20.0, 0.5),
            "max_velocity": (0.5, 10.0, 0.1),
        }
    
    def __init__(self):
        super().__init__()
        self._params = self.default_params.copy()
    
    def update(self, target: Tuple[float, float], dt: float) -> Tuple[float, float]:
        """Update Newtonian physics simulation."""
        accel = self.get_param("acceleration")
        friction = self.get_param("friction")
        max_vel = self.get_param("max_velocity")
        
        px, py = self.state.position
        vx, vy = self.state.velocity
        tx, ty = target
        
        # Calculate direction to target
        dx = tx - px
        dy = ty - py
        
        # Accelerate towards target
        vx += dx * accel * dt
        vy += dy * accel * dt
        
        # Apply friction (opposes velocity)
        friction_factor = max(0, 1 - friction * dt)
        vx *= friction_factor
        vy *= friction_factor
        
        # Clamp velocity
        speed = math.sqrt(vx * vx + vy * vy)
        if speed > max_vel:
            vx = (vx / speed) * max_vel
            vy = (vy / speed) * max_vel
        
        # Update position
        px += vx * dt
        py += vy * dt
        
        # Clamp position
        px = self.clamp(px)
        py = self.clamp(py)
        
        # Stop at boundaries
        if abs(px) >= 1.0:
            vx = 0
        if abs(py) >= 1.0:
            vy = 0
        
        self.state.position = (px, py)
        self.state.velocity = (vx, vy)
        self.state.target = target
        
        return self.state.position


class MomentumModel(PhysicsModel):
    """
    Momentum-focused model with variable inertia.
    
    Heavier feeling with configurable "weight" based on current speed.
    
    Good for: Racing games, heavy machinery simulation
    """
    
    name = "momentum"
    description = "Heavy, inertial movement with speed-dependent response"
    
    @property
    def default_params(self) -> Dict[str, Any]:
        return {
            "base_inertia": 2.0,      # Base mass/inertia
            "speed_inertia": 1.0,     # Additional inertia based on speed
            "thrust": 20.0,           # Force applied towards target
            "drag": 3.0,              # Air resistance
        }
    
    @property
    def param_ranges(self) -> Dict[str, Tuple[float, float, float]]:
        return {
            "base_inertia": (0.5, 10.0, 0.1),
            "speed_inertia": (0.0, 5.0, 0.1),
            "thrust": (5.0, 50.0, 1.0),
            "drag": (0.5, 10.0, 0.5),
        }
    
    def __init__(self):
        super().__init__()
        self._params = self.default_params.copy()
    
    def update(self, target: Tuple[float, float], dt: float) -> Tuple[float, float]:
        """Update momentum physics."""
        base_inertia = self.get_param("base_inertia")
        speed_inertia = self.get_param("speed_inertia")
        thrust = self.get_param("thrust")
        drag = self.get_param("drag")
        
        px, py = self.state.position
        vx, vy = self.state.velocity
        tx, ty = target
        
        # Current speed affects inertia
        speed = math.sqrt(vx * vx + vy * vy)
        effective_mass = base_inertia + speed_inertia * speed
        
        # Direction to target
        dx = tx - px
        dy = ty - py
        
        # Apply thrust force
        fx = dx * thrust
        fy = dy * thrust
        
        # Apply drag (quadratic with velocity)
        if speed > 0.001:
            drag_force = drag * speed
            fx -= (vx / speed) * drag_force
            fy -= (vy / speed) * drag_force
        
        # Acceleration = Force / Mass
        ax = fx / effective_mass
        ay = fy / effective_mass
        
        # Integrate
        vx += ax * dt
        vy += ay * dt
        px += vx * dt
        py += vy * dt
        
        # Clamp
        px = self.clamp(px)
        py = self.clamp(py)
        
        self.state.position = (px, py)
        self.state.velocity = (vx, vy)
        self.state.target = target
        
        return self.state.position
