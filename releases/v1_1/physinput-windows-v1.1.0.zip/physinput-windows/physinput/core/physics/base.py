"""
Base physics model for analog stick simulation.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Tuple, Dict, Any
import math


@dataclass
class PhysicsState:
    """Current state of the physics simulation."""
    position: Tuple[float, float] = (0.0, 0.0)
    velocity: Tuple[float, float] = (0.0, 0.0)
    target: Tuple[float, float] = (0.0, 0.0)
    
    def reset(self):
        """Reset state to origin."""
        self.position = (0.0, 0.0)
        self.velocity = (0.0, 0.0)
        self.target = (0.0, 0.0)


class PhysicsModel(ABC):
    """Abstract base class for physics models."""
    
    name: str = "base"
    description: str = "Base physics model"
    
    def __init__(self):
        self.state = PhysicsState()
        self._params: Dict[str, Any] = {}
    
    @property
    @abstractmethod
    def default_params(self) -> Dict[str, Any]:
        """Return default parameters for this model."""
        pass
    
    @property
    @abstractmethod 
    def param_ranges(self) -> Dict[str, Tuple[float, float, float]]:
        """Return parameter ranges as {name: (min, max, step)}."""
        pass
    
    @property
    def params(self) -> Dict[str, Any]:
        """Get current parameters."""
        return self._params
    
    @params.setter
    def params(self, value: Dict[str, Any]):
        """Set parameters."""
        self._params = {**self.default_params, **value}
    
    def get_param(self, name: str) -> Any:
        """Get a specific parameter."""
        return self._params.get(name, self.default_params.get(name))
    
    def set_param(self, name: str, value: Any):
        """Set a specific parameter."""
        self._params[name] = value
    
    @abstractmethod
    def update(self, target: Tuple[float, float], dt: float) -> Tuple[float, float]:
        """
        Update physics simulation.
        
        Args:
            target: Target position (-1 to 1 for each axis)
            dt: Delta time in seconds
            
        Returns:
            Current output position (-1 to 1 for each axis)
        """
        pass
    
    def reset(self):
        """Reset simulation state."""
        self.state.reset()
    
    @staticmethod
    def clamp(value: float, min_val: float = -1.0, max_val: float = 1.0) -> float:
        """Clamp value to range."""
        return max(min_val, min(max_val, value))
    
    @staticmethod
    def apply_circular_constraint(x: float, y: float) -> Tuple[float, float]:
        """Constrain output to circular bounds."""
        magnitude = math.sqrt(x * x + y * y)
        if magnitude > 1.0:
            x /= magnitude
            y /= magnitude
        return x, y
    
    @staticmethod
    def apply_deadzone(x: float, y: float, deadzone: float) -> Tuple[float, float]:
        """Apply deadzone to output."""
        magnitude = math.sqrt(x * x + y * y)
        if magnitude < deadzone:
            return 0.0, 0.0
        # Scale remaining range
        scale = (magnitude - deadzone) / (1.0 - deadzone)
        if magnitude > 0:
            x = (x / magnitude) * scale
            y = (y / magnitude) * scale
        return x, y
