"""
Windows input handler using pynput.
Captures keyboard and mouse input.
"""

import time
import threading
from typing import Optional, Tuple, Dict, Callable
from dataclasses import dataclass, field
from collections import deque

from pynput import keyboard, mouse


@dataclass
class MouseState:
    """Current mouse state."""
    x: float = 0.0
    y: float = 0.0
    velocity_x: float = 0.0
    velocity_y: float = 0.0
    buttons: Dict[str, bool] = field(default_factory=dict)


@dataclass
class KeyboardState:
    """Current keyboard state."""
    keys: Dict[str, bool] = field(default_factory=dict)


def key_to_name(key) -> Optional[str]:
    """Convert pynput key to name."""
    try:
        if hasattr(key, 'char') and key.char:
            return key.char.lower()
        if hasattr(key, 'name'):
            name = key.name.lower()
            mapping = {
                'space': 'space', 'enter': 'enter', 'tab': 'tab',
                'backspace': 'backspace', 'delete': 'delete',
                'esc': 'escape', 'escape': 'escape',
                'up': 'up', 'down': 'down', 'left': 'left', 'right': 'right',
                'shift': 'shift', 'shift_l': 'shift', 'shift_r': 'rshift',
                'ctrl': 'ctrl', 'ctrl_l': 'ctrl', 'ctrl_r': 'rctrl',
                'alt': 'alt', 'alt_l': 'alt', 'alt_r': 'ralt',
                'cmd': 'super', 'cmd_l': 'super',
                'caps_lock': 'capslock', 'pause': 'pause',
                'f1': 'f1', 'f2': 'f2', 'f3': 'f3', 'f4': 'f4',
                'f5': 'f5', 'f6': 'f6', 'f7': 'f7', 'f8': 'f8',
                'f9': 'f9', 'f10': 'f10', 'f11': 'f11', 'f12': 'f12',
            }
            return mapping.get(name, name)
    except:
        pass
    return None


def button_to_name(button) -> Optional[str]:
    """Convert pynput mouse button to name."""
    mapping = {
        mouse.Button.left: 'mouse_left',
        mouse.Button.right: 'mouse_right',
        mouse.Button.middle: 'mouse_middle',
    }
    return mapping.get(button)


class InputHandler:
    """Windows input handler using pynput."""
    
    def __init__(self):
        self.keyboard_state = KeyboardState()
        self.mouse_state = MouseState()
        
        self._kb_listener: Optional[keyboard.Listener] = None
        self._mouse_listener: Optional[mouse.Listener] = None
        self._running = False
        
        self._last_mouse_time = time.time()
        self._mouse_acc = [0.0, 0.0]
        self._velocity_history: deque = deque(maxlen=10)
        self._last_mouse_pos = None
        
        self._update_thread: Optional[threading.Thread] = None
        
        self.on_key_event: Optional[Callable[[str, bool], None]] = None
        self.on_mouse_move: Optional[Callable[[float, float], None]] = None
        self.on_mouse_button: Optional[Callable[[str, bool], None]] = None
    
    def start(self) -> bool:
        if self._running:
            return True
        
        try:
            self._kb_listener = keyboard.Listener(
                on_press=self._on_press,
                on_release=self._on_release
            )
            self._kb_listener.start()
            
            self._mouse_listener = mouse.Listener(
                on_move=self._on_move,
                on_click=self._on_click
            )
            self._mouse_listener.start()
            
            self._running = True
            self._update_thread = threading.Thread(target=self._velocity_loop, daemon=True)
            self._update_thread.start()
            
            return True
        except Exception as e:
            print(f"Failed to start input: {e}")
            self.stop()
            return False
    
    def stop(self):
        self._running = False
        
        if self._kb_listener:
            self._kb_listener.stop()
            self._kb_listener = None
        
        if self._mouse_listener:
            self._mouse_listener.stop()
            self._mouse_listener = None
        
        if self._update_thread:
            self._update_thread.join(timeout=1)
            self._update_thread = None
    
    def is_key_pressed(self, key: str) -> bool:
        return self.keyboard_state.keys.get(key.lower(), False)
    
    def get_mouse_velocity(self) -> Tuple[float, float]:
        return (self.mouse_state.velocity_x, self.mouse_state.velocity_y)
    
    def get_smoothed_velocity(self, frames: int = 3) -> Tuple[float, float]:
        if not self._velocity_history:
            return (0.0, 0.0)
        hist = list(self._velocity_history)[-frames:]
        if not hist:
            return (0.0, 0.0)
        return (
            sum(v[0] for v in hist) / len(hist),
            sum(v[1] for v in hist) / len(hist)
        )
    
    def _on_press(self, key):
        name = key_to_name(key)
        if name:
            self.keyboard_state.keys[name] = True
            if self.on_key_event:
                self.on_key_event(name, True)
    
    def _on_release(self, key):
        name = key_to_name(key)
        if name:
            self.keyboard_state.keys[name] = False
            if self.on_key_event:
                self.on_key_event(name, False)
    
    def _on_move(self, x, y):
        if self._last_mouse_pos is None:
            self._last_mouse_pos = (x, y)
            return
        
        dx = x - self._last_mouse_pos[0]
        dy = y - self._last_mouse_pos[1]
        self._last_mouse_pos = (x, y)
        
        self._mouse_acc[0] += dx
        self._mouse_acc[1] += dy
    
    def _on_click(self, x, y, button, pressed):
        name = button_to_name(button)
        if name:
            self.mouse_state.buttons[name] = pressed
            if self.on_mouse_button:
                self.on_mouse_button(name, pressed)
    
    def _velocity_loop(self):
        while self._running:
            now = time.time()
            dt = now - self._last_mouse_time
            
            if dt >= 0.008:
                vx = self._mouse_acc[0] / dt
                vy = self._mouse_acc[1] / dt
                
                self.mouse_state.x = self._mouse_acc[0]
                self.mouse_state.y = self._mouse_acc[1]
                self.mouse_state.velocity_x = vx
                self.mouse_state.velocity_y = vy
                
                self._velocity_history.append((vx, vy))
                
                if self.on_mouse_move and (self.mouse_state.x or self.mouse_state.y):
                    self.on_mouse_move(self.mouse_state.x, self.mouse_state.y)
                
                self._mouse_acc = [0.0, 0.0]
                self._last_mouse_time = now
            
            time.sleep(0.001)
    
    def clear_state(self):
        self.keyboard_state.keys.clear()
        self.mouse_state.buttons.clear()
        self.mouse_state.velocity_x = 0
        self.mouse_state.velocity_y = 0
