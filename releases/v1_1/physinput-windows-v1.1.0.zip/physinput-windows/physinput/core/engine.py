"""
Main engine for PhysInput Linux - orchestrates input, physics, and output.
"""

import math
import time
import threading
from typing import Optional, Callable, Dict, Tuple
from dataclasses import dataclass, field
from collections import deque

from .config import Config
from .input_handler import InputHandler
from .output_handler import OutputHandler
from .physics import get_model, PhysicsModel, PHYSICS_MODELS


@dataclass
class PerformanceStats:
    """Performance tracking."""
    fps: float = 0.0
    frame_time_ms: float = 0.0
    _frame_times: deque = field(default_factory=lambda: deque(maxlen=60))
    
    def record_frame(self, dt: float):
        self._frame_times.append(dt)
        if self._frame_times:
            avg = sum(self._frame_times) / len(self._frame_times)
            self.fps = 1.0 / avg if avg > 0 else 0
            self.frame_time_ms = avg * 1000


class Engine:
    """Main PhysInput engine."""
    
    def __init__(self, config: Optional[Config] = None):
        self.config = config or Config()
        
        self.input: Optional[InputHandler] = None
        self.output: Optional[OutputHandler] = None
        
        self.left_physics: PhysicsModel = get_model(self.config.physics.model)
        self.right_physics: PhysicsModel = get_model(self.config.physics.model)
        self._apply_physics_config()
        
        self._running = False
        self._enabled = False
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()
        
        self.left_stick = (0.0, 0.0)
        self.right_stick = (0.0, 0.0)
        self.left_trigger = 0.0
        self.right_trigger = 0.0
        
        self._key_states: Dict[str, bool] = {}
        self._mouse_velocity = (0.0, 0.0)
        
        self._trigger_press_time: Dict[str, float] = {}
        
        self.stats = PerformanceStats()
        self._last_update = time.time()
        
        self.on_state_change: Optional[Callable[[bool], None]] = None
    
    def _apply_physics_config(self):
        params = {
            'stiffness': self.config.physics.stiffness,
            'damping': self.config.physics.damping,
            'mass': self.config.physics.mass,
        }
        self.left_physics.params = params
        self.right_physics.params = params
    
    def set_physics_model(self, name: str):
        if name in PHYSICS_MODELS:
            self.config.physics.model = name
            self.left_physics = get_model(name)
            self.right_physics = get_model(name)
            self._apply_physics_config()
    
    def set_physics_param(self, name: str, value: float):
        if hasattr(self.config.physics, name):
            setattr(self.config.physics, name, value)
        self.left_physics.set_param(name, value)
        self.right_physics.set_param(name, value)
    
    def start(self) -> bool:
        if self._running:
            return True
        
        try:
            self.input = InputHandler()
            self.output = OutputHandler()
            
            self.input.on_key_event = self._on_key
            self.input.on_mouse_move = self._on_mouse
            self.input.on_mouse_button = self._on_mouse_btn
            
            if not self.input.start():
                print("Failed to start input capture")
                return False
            
            self.output.set_identity(self.config.device.identity)
            if not self.output.create_device():
                print("Failed to create virtual gamepad")
                self.input.stop()
                return False
            
            self._running = True
            self._enabled = True
            self._thread = threading.Thread(target=self._loop, daemon=True)
            self._thread.start()
            
            if self.on_state_change:
                self.on_state_change(True)
            return True
            
        except Exception as e:
            print(f"Engine start failed: {e}")
            self.stop()
            return False
    
    def stop(self):
        self._running = False
        self._enabled = False
        
        if self._thread:
            self._thread.join(timeout=2)
            self._thread = None
        
        if self.input:
            self.input.stop()
            self.input = None
        
        if self.output:
            self.output.close_device()
            self.output = None
        
        if self.on_state_change:
            self.on_state_change(False)
    
    def toggle(self):
        self._enabled = not self._enabled
        if not self._enabled and self.output:
            self.output.set_left_stick(0, 0)
            self.output.set_right_stick(0, 0)
            self.output.set_triggers(0, 0)
            self.output.sync()
            self.left_physics.reset()
            self.right_physics.reset()
    
    @property
    def is_running(self) -> bool:
        return self._running
    
    @property
    def is_enabled(self) -> bool:
        return self._enabled
    
    def _on_key(self, key: str, pressed: bool):
        with self._lock:
            self._key_states[key] = pressed
            
            if key == self.config.hotkey and pressed:
                self.toggle()
                return
            
            if key in self.config.button_bindings:
                self._handle_binding(self.config.button_bindings[key], pressed)
    
    def _on_mouse(self, dx: float, dy: float):
        if self.config.mouse.enabled and self.input:
            vel = self.input.get_smoothed_velocity(self.config.mouse.smoothing_frames)
            with self._lock:
                self._mouse_velocity = vel
    
    def _on_mouse_btn(self, btn: str, pressed: bool):
        if btn in self.config.button_bindings:
            self._handle_binding(self.config.button_bindings[btn], pressed)
    
    def _handle_binding(self, binding: str, pressed: bool):
        b = binding.upper()
        if b in ('LT', 'RT'):
            if pressed:
                self._trigger_press_time[b] = time.time()
            else:
                self._trigger_press_time.pop(b, None)
            if not self.config.physics.trigger_ramp_enabled:
                val = 1.0 if pressed else 0.0
                if b == 'LT':
                    self.left_trigger = val
                else:
                    self.right_trigger = val
        else:
            if self.output:
                self.output.set_button(binding, pressed)
                self.output.sync()
    
    def _loop(self):
        target_dt = 1.0 / self.config.target_fps
        
        while self._running:
            start = time.time()
            dt = start - self._last_update
            self._last_update = start
            
            if self._enabled:
                self._update(dt)
            
            self.stats.record_frame(dt)
            
            elapsed = time.time() - start
            if elapsed < target_dt:
                time.sleep(target_dt - elapsed)
    
    def _update(self, dt: float):
        with self._lock:
            left_target = self._get_left_target()
            right_target = self._get_right_target()
        
        left_out = self.left_physics.update(left_target, dt)
        right_out = self.right_physics.update(right_target, dt)
        
        if self.config.physics.circular_constraint:
            left_out = PhysicsModel.apply_circular_constraint(*left_out)
        if self.config.mouse.circular_constraint:
            right_out = PhysicsModel.apply_circular_constraint(*right_out)
        
        self.left_stick = left_out
        self.right_stick = right_out
        
        self._update_triggers(dt)
        
        if self.output:
            self.output.set_left_stick(*self.left_stick)
            self.output.set_right_stick(*self.right_stick)
            self.output.set_triggers(self.left_trigger, self.right_trigger)
            self.output.sync()
    
    def _get_left_target(self) -> Tuple[float, float]:
        keys = self.config.movement_keys
        x = y = 0.0
        if self._key_states.get(keys.left): x -= 1
        if self._key_states.get(keys.right): x += 1
        if self._key_states.get(keys.up): y += 1
        if self._key_states.get(keys.down): y -= 1
        
        if x and y:
            l = math.sqrt(x*x + y*y)
            x, y = x/l, y/l
        return (x, y)
    
    def _get_right_target(self) -> Tuple[float, float]:
        if not self.config.mouse.enabled:
            return (0.0, 0.0)
        
        cfg = self.config.mouse
        vx, vy = self._mouse_velocity
        vx *= cfg.sensitivity
        vy *= cfg.sensitivity
        
        speed = math.sqrt(vx*vx + vy*vy)
        
        if speed < cfg.velocity_min_threshold:
            return (0.0, 0.0)
        
        if speed > 0:
            norm = min(1.0, (speed - cfg.velocity_min_threshold) / 
                      (cfg.velocity_threshold - cfg.velocity_min_threshold))
            if cfg.acceleration_curve != 1.0:
                norm = pow(norm, cfg.acceleration_curve)
            x = (vx / speed) * norm
            y = (vy / speed) * norm
        else:
            x, y = 0.0, 0.0
        
        if cfg.invert_x: x = -x
        if cfg.invert_y: y = -y
        
        return (max(-1, min(1, x)), max(-1, min(1, y)))
    
    def _update_triggers(self, dt: float):
        for t in ['LT', 'RT']:
            if t in self._trigger_press_time:
                if self.config.physics.trigger_ramp_enabled:
                    elapsed = time.time() - self._trigger_press_time[t]
                    ramp = self.config.physics.trigger_ramp_time
                    val = min(1.0, elapsed / ramp) if ramp > 0 else 1.0
                else:
                    val = 1.0
            else:
                val = 0.0
            
            if t == 'LT':
                self.left_trigger = val
            else:
                self.right_trigger = val
