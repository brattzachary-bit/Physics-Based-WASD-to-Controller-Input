"""PhysInput Core - Windows version."""

from .config import (
    Config, PhysicsConfig, MouseConfig, MovementKeys, DeviceConfig, UIConfig,
    DEVICE_IDENTITIES, load_config, save_config, list_profiles, load_profile,
    save_profile, delete_profile, export_profile, import_profile, load_game_presets,
)
from .input_handler import InputHandler
from .output_handler import OutputHandler
from .engine import Engine, PerformanceStats
from .physics import PhysicsModel, PhysicsState, PHYSICS_MODELS, get_model, list_models

__all__ = [
    'Config', 'PhysicsConfig', 'MouseConfig', 'MovementKeys', 'DeviceConfig', 'UIConfig',
    'DEVICE_IDENTITIES', 'load_config', 'save_config', 'list_profiles', 'load_profile',
    'save_profile', 'delete_profile', 'export_profile', 'import_profile', 'load_game_presets',
    'InputHandler', 'OutputHandler', 'Engine', 'PerformanceStats',
    'PhysicsModel', 'PhysicsState', 'PHYSICS_MODELS', 'get_model', 'list_models',
]
