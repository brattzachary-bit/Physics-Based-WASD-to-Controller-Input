"""
Windows output handler - Creates virtual gamepad using vgamepad (ViGEmBus).

Requires:
- vgamepad: pip install vgamepad
- ViGEmBus driver: https://github.com/ViGEm/ViGEmBus/releases
"""

import time
from typing import Optional
from dataclasses import dataclass, field
from typing import Dict

import vgamepad as vg


@dataclass
class GamepadState:
    """Current gamepad output state."""
    left_stick_x: float = 0.0
    left_stick_y: float = 0.0
    right_stick_x: float = 0.0
    right_stick_y: float = 0.0
    left_trigger: float = 0.0
    right_trigger: float = 0.0
    dpad_up: bool = False
    dpad_down: bool = False
    dpad_left: bool = False
    dpad_right: bool = False
    buttons: Dict[str, bool] = field(default_factory=dict)


class OutputHandler:
    """Windows virtual gamepad using ViGEmBus."""
    
    def __init__(self):
        self.state = GamepadState()
        self._gamepad = None
        self._identity = "xbox360"
    
    def set_identity(self, identity: str):
        """Set device identity (xbox360 or ds4)."""
        self._identity = identity
    
    def create_device(self) -> bool:
        """Create the virtual gamepad."""
        if self._gamepad is not None:
            self.close_device()
        
        try:
            if self._identity in ("ds4", "dualsense"):
                self._gamepad = vg.VDS4Gamepad()
            else:
                self._gamepad = vg.VX360Gamepad()
            
            time.sleep(0.1)
            return True
            
        except Exception as e:
            print(f"Failed to create virtual gamepad: {e}")
            print("Make sure ViGEmBus is installed:")
            print("https://github.com/ViGEm/ViGEmBus/releases")
            self._gamepad = None
            return False
    
    def close_device(self):
        """Close the virtual gamepad."""
        if self._gamepad:
            try:
                self.set_left_stick(0, 0)
                self.set_right_stick(0, 0)
                self.set_triggers(0, 0)
                self.sync()
            except:
                pass
            self._gamepad = None
    
    def set_left_stick(self, x: float, y: float):
        if not self._gamepad: return
        self.state.left_stick_x, self.state.left_stick_y = x, y
        x, y = max(-1, min(1, x)), max(-1, min(1, y))
        self._gamepad.left_joystick_float(x_value_float=x, y_value_float=y)
    
    def set_right_stick(self, x: float, y: float):
        if not self._gamepad: return
        self.state.right_stick_x, self.state.right_stick_y = x, y
        x, y = max(-1, min(1, x)), max(-1, min(1, y))
        self._gamepad.right_joystick_float(x_value_float=x, y_value_float=y)
    
    def set_triggers(self, left: float, right: float):
        if not self._gamepad: return
        self.state.left_trigger, self.state.right_trigger = left, right
        left, right = max(0, min(1, left)), max(0, min(1, right))
        self._gamepad.left_trigger_float(value_float=left)
        self._gamepad.right_trigger_float(value_float=right)
    
    def set_button(self, button: str, pressed: bool):
        if not self._gamepad: return
        
        b = button.upper()
        
        if b in ('LT', 'LEFT_TRIGGER'):
            self.state.left_trigger = 1.0 if pressed else 0.0
            self._gamepad.left_trigger_float(value_float=self.state.left_trigger)
            return
        elif b in ('RT', 'RIGHT_TRIGGER'):
            self.state.right_trigger = 1.0 if pressed else 0.0
            self._gamepad.right_trigger_float(value_float=self.state.right_trigger)
            return
        
        if b.startswith('DPAD_'):
            setattr(self.state, b.lower(), pressed)
            self._update_dpad()
            return
        
        # Xbox 360 buttons
        if isinstance(self._gamepad, vg.VX360Gamepad):
            btn_map = {
                'BTN_SOUTH': vg.XUSB_BUTTON.XUSB_GAMEPAD_A, 'A': vg.XUSB_BUTTON.XUSB_GAMEPAD_A,
                'BTN_EAST': vg.XUSB_BUTTON.XUSB_GAMEPAD_B, 'B': vg.XUSB_BUTTON.XUSB_GAMEPAD_B,
                'BTN_WEST': vg.XUSB_BUTTON.XUSB_GAMEPAD_X, 'X': vg.XUSB_BUTTON.XUSB_GAMEPAD_X,
                'BTN_NORTH': vg.XUSB_BUTTON.XUSB_GAMEPAD_Y, 'Y': vg.XUSB_BUTTON.XUSB_GAMEPAD_Y,
                'BTN_TL': vg.XUSB_BUTTON.XUSB_GAMEPAD_LEFT_SHOULDER, 'LB': vg.XUSB_BUTTON.XUSB_GAMEPAD_LEFT_SHOULDER,
                'BTN_TR': vg.XUSB_BUTTON.XUSB_GAMEPAD_RIGHT_SHOULDER, 'RB': vg.XUSB_BUTTON.XUSB_GAMEPAD_RIGHT_SHOULDER,
                'BTN_SELECT': vg.XUSB_BUTTON.XUSB_GAMEPAD_BACK, 'BACK': vg.XUSB_BUTTON.XUSB_GAMEPAD_BACK,
                'BTN_START': vg.XUSB_BUTTON.XUSB_GAMEPAD_START, 'START': vg.XUSB_BUTTON.XUSB_GAMEPAD_START,
                'BTN_MODE': vg.XUSB_BUTTON.XUSB_GAMEPAD_GUIDE, 'GUIDE': vg.XUSB_BUTTON.XUSB_GAMEPAD_GUIDE,
                'BTN_THUMBL': vg.XUSB_BUTTON.XUSB_GAMEPAD_LEFT_THUMB, 'L3': vg.XUSB_BUTTON.XUSB_GAMEPAD_LEFT_THUMB,
                'BTN_THUMBR': vg.XUSB_BUTTON.XUSB_GAMEPAD_RIGHT_THUMB, 'R3': vg.XUSB_BUTTON.XUSB_GAMEPAD_RIGHT_THUMB,
            }
            
            if b in btn_map:
                self.state.buttons[b] = pressed
                if pressed:
                    self._gamepad.press_button(button=btn_map[b])
                else:
                    self._gamepad.release_button(button=btn_map[b])
        else:
            # DS4 buttons
            btn_map = {
                'BTN_SOUTH': vg.DS4_BUTTONS.DS4_BUTTON_CROSS, 'A': vg.DS4_BUTTONS.DS4_BUTTON_CROSS,
                'BTN_EAST': vg.DS4_BUTTONS.DS4_BUTTON_CIRCLE, 'B': vg.DS4_BUTTONS.DS4_BUTTON_CIRCLE,
                'BTN_WEST': vg.DS4_BUTTONS.DS4_BUTTON_SQUARE, 'X': vg.DS4_BUTTONS.DS4_BUTTON_SQUARE,
                'BTN_NORTH': vg.DS4_BUTTONS.DS4_BUTTON_TRIANGLE, 'Y': vg.DS4_BUTTONS.DS4_BUTTON_TRIANGLE,
                'BTN_TL': vg.DS4_BUTTONS.DS4_BUTTON_SHOULDER_LEFT, 'LB': vg.DS4_BUTTONS.DS4_BUTTON_SHOULDER_LEFT,
                'BTN_TR': vg.DS4_BUTTONS.DS4_BUTTON_SHOULDER_RIGHT, 'RB': vg.DS4_BUTTONS.DS4_BUTTON_SHOULDER_RIGHT,
                'BTN_SELECT': vg.DS4_BUTTONS.DS4_BUTTON_SHARE, 'BACK': vg.DS4_BUTTONS.DS4_BUTTON_SHARE,
                'BTN_START': vg.DS4_BUTTONS.DS4_BUTTON_OPTIONS, 'START': vg.DS4_BUTTONS.DS4_BUTTON_OPTIONS,
                'BTN_THUMBL': vg.DS4_BUTTONS.DS4_BUTTON_THUMB_LEFT, 'L3': vg.DS4_BUTTONS.DS4_BUTTON_THUMB_LEFT,
                'BTN_THUMBR': vg.DS4_BUTTONS.DS4_BUTTON_THUMB_RIGHT, 'R3': vg.DS4_BUTTONS.DS4_BUTTON_THUMB_RIGHT,
            }
            
            if b in btn_map:
                self.state.buttons[b] = pressed
                if pressed:
                    self._gamepad.press_button(button=btn_map[b])
                else:
                    self._gamepad.release_button(button=btn_map[b])
    
    def _update_dpad(self):
        if isinstance(self._gamepad, vg.VX360Gamepad):
            self._gamepad.release_button(button=vg.XUSB_BUTTON.XUSB_GAMEPAD_DPAD_UP)
            self._gamepad.release_button(button=vg.XUSB_BUTTON.XUSB_GAMEPAD_DPAD_DOWN)
            self._gamepad.release_button(button=vg.XUSB_BUTTON.XUSB_GAMEPAD_DPAD_LEFT)
            self._gamepad.release_button(button=vg.XUSB_BUTTON.XUSB_GAMEPAD_DPAD_RIGHT)
            
            if self.state.dpad_up:
                self._gamepad.press_button(button=vg.XUSB_BUTTON.XUSB_GAMEPAD_DPAD_UP)
            if self.state.dpad_down:
                self._gamepad.press_button(button=vg.XUSB_BUTTON.XUSB_GAMEPAD_DPAD_DOWN)
            if self.state.dpad_left:
                self._gamepad.press_button(button=vg.XUSB_BUTTON.XUSB_GAMEPAD_DPAD_LEFT)
            if self.state.dpad_right:
                self._gamepad.press_button(button=vg.XUSB_BUTTON.XUSB_GAMEPAD_DPAD_RIGHT)
        else:
            # DS4 D-pad
            direction = vg.DS4_DPAD_DIRECTIONS.DS4_BUTTON_DPAD_NONE
            
            if self.state.dpad_up and not self.state.dpad_down:
                if self.state.dpad_left:
                    direction = vg.DS4_DPAD_DIRECTIONS.DS4_BUTTON_DPAD_NORTHWEST
                elif self.state.dpad_right:
                    direction = vg.DS4_DPAD_DIRECTIONS.DS4_BUTTON_DPAD_NORTHEAST
                else:
                    direction = vg.DS4_DPAD_DIRECTIONS.DS4_BUTTON_DPAD_NORTH
            elif self.state.dpad_down and not self.state.dpad_up:
                if self.state.dpad_left:
                    direction = vg.DS4_DPAD_DIRECTIONS.DS4_BUTTON_DPAD_SOUTHWEST
                elif self.state.dpad_right:
                    direction = vg.DS4_DPAD_DIRECTIONS.DS4_BUTTON_DPAD_SOUTHEAST
                else:
                    direction = vg.DS4_DPAD_DIRECTIONS.DS4_BUTTON_DPAD_SOUTH
            elif self.state.dpad_left:
                direction = vg.DS4_DPAD_DIRECTIONS.DS4_BUTTON_DPAD_WEST
            elif self.state.dpad_right:
                direction = vg.DS4_DPAD_DIRECTIONS.DS4_BUTTON_DPAD_EAST
            
            self._gamepad.directional_pad(direction=direction)
    
    def sync(self):
        if self._gamepad:
            self._gamepad.update()
    
    @property
    def is_active(self) -> bool:
        return self._gamepad is not None
