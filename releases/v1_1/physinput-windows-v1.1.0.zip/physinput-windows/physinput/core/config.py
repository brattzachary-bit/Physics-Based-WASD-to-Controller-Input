"""
Configuration management for PhysInput.
Handles loading, saving, and validating configuration.
"""

import json
import copy
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional, Any
from pathlib import Path

from physinput import CONFIG_FILE, PROFILES_DIR, PRESETS_DIR, APP_DATA


# Device identity presets (for uinput device spoofing)
DEVICE_IDENTITIES = {
    "xbox360": {
        "name": "Microsoft X-Box 360 pad",
        "vendor": 0x045E,
        "product": 0x028E,
        "version": 0x0110
    },
    "xboxone": {
        "name": "Microsoft Xbox One Controller", 
        "vendor": 0x045E,
        "product": 0x02DD,
        "version": 0x0100
    },
    "xboxsx": {
        "name": "Microsoft Xbox Series X Controller",
        "vendor": 0x045E,
        "product": 0x0B12,
        "version": 0x0507
    },
    "ds4": {
        "name": "Sony DualShock 4",
        "vendor": 0x054C,
        "product": 0x09CC,
        "version": 0x0100
    },
    "dualsense": {
        "name": "Sony DualSense",
        "vendor": 0x054C,
        "product": 0x0CE6,
        "version": 0x8100
    },
    "generic": {
        "name": "Generic Gamepad",
        "vendor": 0x0001,
        "product": 0x0001,
        "version": 0x0100
    },
}


@dataclass
class PhysicsConfig:
    """Physics model configuration."""
    model: str = "spring"
    # Spring model params
    stiffness: float = 80.0
    damping: float = 12.0
    mass: float = 1.0
    # Newtonian params
    acceleration: float = 15.0
    friction: float = 8.0
    max_velocity: float = 1.0
    # PID params
    kp: float = 10.0
    ki: float = 0.5
    kd: float = 2.0
    # Fluid params
    viscosity: float = 5.0
    inertia: float = 0.8
    # Return behavior
    left_stick_return_time: float = 0.0
    right_stick_return_time: float = 0.15
    circular_constraint: bool = False
    # Trigger ramping
    trigger_ramp_enabled: bool = False
    trigger_ramp_time: float = 0.1


@dataclass 
class MouseConfig:
    """Mouse input configuration."""
    enabled: bool = True
    sensitivity: float = 1.0
    smoothing: float = 0.0
    deadzone: float = 0.02
    invert_x: bool = False
    invert_y: bool = False
    # Velocity mode
    velocity_mode: bool = True
    velocity_threshold: float = 2000.0
    velocity_min_threshold: float = 50.0
    acceleration_curve: float = 1.0
    # Smoothing
    smoothing_enabled: bool = True
    smoothing_frames: int = 3
    circular_constraint: bool = False


@dataclass
class MovementKeys:
    """Movement key bindings."""
    up: str = "w"
    down: str = "s"
    left: str = "a"
    right: str = "d"


@dataclass
class DeviceConfig:
    """Virtual device configuration."""
    identity: str = "xbox360"
    custom_name: str = "PhysInput Controller"
    custom_vendor: str = "045e"
    custom_product: str = "028e"


@dataclass
class UIConfig:
    """UI configuration."""
    always_on_top: bool = False
    show_overlay: bool = False
    overlay_opacity: float = 0.8
    overlay_size: int = 150
    theme: str = "dark"
    show_graphs: bool = True
    graph_history: int = 100


@dataclass
class Config:
    """Main application configuration."""
    physics: PhysicsConfig = field(default_factory=PhysicsConfig)
    mouse: MouseConfig = field(default_factory=MouseConfig)
    movement_keys: MovementKeys = field(default_factory=MovementKeys)
    device: DeviceConfig = field(default_factory=DeviceConfig)
    ui: UIConfig = field(default_factory=UIConfig)
    button_bindings: Dict[str, str] = field(default_factory=dict)
    intercepted_keys: List[str] = field(default_factory=list)
    selective_grab: bool = False
    passthrough: bool = True
    hotkey: str = "pause"
    target_fps: int = 120
    first_run_complete: bool = False
    
    def to_dict(self) -> dict:
        """Convert config to dictionary."""
        return {
            "physics": asdict(self.physics),
            "mouse": asdict(self.mouse),
            "movement_keys": asdict(self.movement_keys),
            "device": asdict(self.device),
            "ui": asdict(self.ui),
            "button_bindings": self.button_bindings,
            "intercepted_keys": self.intercepted_keys,
            "selective_grab": self.selective_grab,
            "passthrough": self.passthrough,
            "hotkey": self.hotkey,
            "target_fps": self.target_fps,
            "first_run_complete": self.first_run_complete,
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> "Config":
        """Create config from dictionary."""
        config = cls()
        
        if "physics" in data:
            for key, value in data["physics"].items():
                if hasattr(config.physics, key):
                    setattr(config.physics, key, value)
        
        if "mouse" in data:
            for key, value in data["mouse"].items():
                if hasattr(config.mouse, key):
                    setattr(config.mouse, key, value)
        
        if "movement_keys" in data:
            for key, value in data["movement_keys"].items():
                if hasattr(config.movement_keys, key):
                    setattr(config.movement_keys, key, value)
        
        if "device" in data:
            for key, value in data["device"].items():
                if hasattr(config.device, key):
                    setattr(config.device, key, value)
        
        if "ui" in data:
            for key, value in data["ui"].items():
                if hasattr(config.ui, key):
                    setattr(config.ui, key, value)
        
        config.button_bindings = data.get("button_bindings", {})
        config.intercepted_keys = data.get("intercepted_keys", [])
        config.selective_grab = data.get("selective_grab", False)
        config.passthrough = data.get("passthrough", True)
        config.hotkey = data.get("hotkey", "pause")
        config.target_fps = data.get("target_fps", 120)
        config.first_run_complete = data.get("first_run_complete", False)
        
        return config


def load_config() -> Config:
    """Load configuration from file."""
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, 'r') as f:
                data = json.load(f)
            return Config.from_dict(data)
        except (json.JSONDecodeError, IOError) as e:
            print(f"Warning: Could not load config: {e}")
    return Config()


def save_config(config: Config) -> bool:
    """Save configuration to file."""
    try:
        CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
        with open(CONFIG_FILE, 'w') as f:
            json.dump(config.to_dict(), f, indent=2)
        return True
    except IOError as e:
        print(f"Error saving config: {e}")
        return False


def list_profiles() -> List[str]:
    """List available profiles."""
    if not PROFILES_DIR.exists():
        return []
    return [f.stem for f in PROFILES_DIR.glob("*.json")]


def load_profile(name: str) -> Optional[Config]:
    """Load a profile by name."""
    filepath = PROFILES_DIR / f"{name}.json"
    if filepath.exists():
        try:
            with open(filepath, 'r') as f:
                data = json.load(f)
            return Config.from_dict(data)
        except (json.JSONDecodeError, IOError):
            pass
    return None


def save_profile(name: str, config: Config) -> bool:
    """Save configuration as a profile."""
    try:
        PROFILES_DIR.mkdir(parents=True, exist_ok=True)
        filepath = PROFILES_DIR / f"{name}.json"
        with open(filepath, 'w') as f:
            json.dump(config.to_dict(), f, indent=2)
        return True
    except IOError:
        return False


def delete_profile(name: str) -> bool:
    """Delete a profile."""
    filepath = PROFILES_DIR / f"{name}.json"
    if filepath.exists():
        try:
            filepath.unlink()
            return True
        except IOError:
            pass
    return False


def export_profile(config: Config, filepath: str) -> bool:
    """Export configuration to a file."""
    try:
        with open(filepath, 'w') as f:
            json.dump(config.to_dict(), f, indent=2)
        return True
    except IOError:
        return False


def import_profile(filepath: str) -> Optional[Config]:
    """Import configuration from a file."""
    try:
        with open(filepath, 'r') as f:
            data = json.load(f)
        return Config.from_dict(data)
    except (json.JSONDecodeError, IOError):
        return None


def load_game_presets() -> Dict[str, dict]:
    """Load game presets from presets directory."""
    presets = {}
    
    # Check both app presets and user presets
    preset_dirs = [PRESETS_DIR]
    
    for preset_dir in preset_dirs:
        if not preset_dir.exists():
            continue
            
        for filepath in preset_dir.glob("*.json"):
            try:
                with open(filepath, 'r') as f:
                    data = json.load(f)
                
                name = filepath.stem
                
                # Support both wrapped and flat formats
                if "config" in data:
                    presets[name] = data
                elif "physics" in data or "mouse" in data:
                    presets[name] = {
                        "description": f"Loaded from {filepath.name}",
                        "config": data
                    }
            except (json.JSONDecodeError, IOError):
                continue
    
    return presets
