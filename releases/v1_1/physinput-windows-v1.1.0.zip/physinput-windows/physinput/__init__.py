"""
PhysInput for Windows - Physics-Based Analog Input
Converts keyboard/mouse to smooth analog joystick output.
"""

__version__ = "1.1.0"
__app_name__ = "PhysInput"

from pathlib import Path

CONFIG_DIR = Path.home() / "AppData" / "Local" / "PhysInput"
PROFILES_DIR = CONFIG_DIR / "profiles"
CONFIG_FILE = CONFIG_DIR / "config.json"
PRESETS_DIR = CONFIG_DIR / "presets"

for d in [CONFIG_DIR, PROFILES_DIR, PRESETS_DIR]:
    d.mkdir(parents=True, exist_ok=True)
