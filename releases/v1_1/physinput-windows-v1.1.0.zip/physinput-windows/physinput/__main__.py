#!/usr/bin/env python3
"""
PhysInput for Windows - Main entry point.
"""

import sys
import argparse


def main():
    parser = argparse.ArgumentParser(description="PhysInput - Physics-based analog input for Windows")
    parser.add_argument('--check', action='store_true', help="Check system requirements")
    parser.add_argument('--profile', type=str, help="Load a profile on startup")
    parser.add_argument('--version', action='store_true', help="Show version")
    args = parser.parse_args()
    
    from physinput import __version__
    
    if args.version:
        print(f"PhysInput {__version__} (Windows)")
        sys.exit(0)
    
    # Check dependencies
    missing = []
    try:
        import pynput
    except ImportError:
        missing.append("pynput")
    try:
        import vgamepad
    except ImportError:
        missing.append("vgamepad")
    try:
        from PyQt6.QtWidgets import QApplication
    except ImportError:
        missing.append("PyQt6")
    
    if args.check:
        print("PhysInput System Check (Windows)")
        print("=" * 40)
        print(f"Dependencies: {'OK' if not missing else 'MISSING'}")
        if missing:
            for m in missing:
                print(f"  - {m}")
        
        # Check ViGEmBus
        vigembus_ok = False
        if 'vgamepad' not in missing:
            try:
                import vgamepad as vg
                pad = vg.VX360Gamepad()
                del pad
                vigembus_ok = True
                print("ViGEmBus: OK")
            except Exception as e:
                print(f"ViGEmBus: NOT WORKING - {e}")
        else:
            print("ViGEmBus: Cannot check (vgamepad not installed)")
        
        if not vigembus_ok:
            print("\nInstall ViGEmBus driver:")
            print("https://github.com/ViGEm/ViGEmBus/releases")
        
        sys.exit(0 if not missing and vigembus_ok else 1)
    
    if missing:
        print("Missing dependencies:")
        for m in missing:
            print(f"  - {m}")
        print("\nInstall with:")
        print("  pip install pynput vgamepad PyQt6")
        print("\nAlso install ViGEmBus driver:")
        print("  https://github.com/ViGEm/ViGEmBus/releases")
        sys.exit(1)
    
    # Start GUI
    from PyQt6.QtWidgets import QApplication
    from PyQt6.QtCore import Qt
    from PyQt6.QtGui import QFont
    
    QApplication.setHighDpiScaleFactorRoundingPolicy(
        Qt.HighDpiScaleFactorRoundingPolicy.PassThrough
    )
    
    app = QApplication(sys.argv)
    app.setApplicationName("PhysInput")
    
    font = QFont("Segoe UI", 10)
    app.setFont(font)
    
    config = None
    if args.profile:
        from physinput.core import load_profile
        config = load_profile(args.profile)
    
    from physinput.ui import MainWindow
    window = MainWindow()
    if config:
        window._load_profile(config)
    window.show()
    
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
