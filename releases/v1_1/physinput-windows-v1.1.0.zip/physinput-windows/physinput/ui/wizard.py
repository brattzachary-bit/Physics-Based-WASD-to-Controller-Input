"""
First-run setup wizard for PhysInput.
"""

from typing import Optional, List, Tuple

from PyQt6.QtWidgets import (
    QWizard, QWizardPage, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QListWidget, QListWidgetItem, QFrame,
    QCheckBox, QComboBox, QMessageBox, QGroupBox
)
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QPixmap, QFont, QIcon

from .theme import COLORS, get_wizard_stylesheet
from .widgets import MovementKeyWidget, KeyCaptureButton
from ..core import Config, DEVICE_IDENTITIES, list_models


class WelcomePage(QWizardPage):
    """Welcome page with introduction."""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self.setTitle("Welcome to PhysInput")
        self.setSubTitle("Physics-based analog input for Linux gaming")
        
        layout = QVBoxLayout(self)
        layout.setSpacing(20)
        
        # Logo placeholder
        logo_frame = QFrame()
        logo_frame.setFixedSize(120, 120)
        logo_frame.setStyleSheet(f"""
            QFrame {{
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 {COLORS['accent_primary']}, stop:1 {COLORS['accent_hover']});
                border-radius: 60px;
            }}
        """)
        
        logo_layout = QVBoxLayout(logo_frame)
        logo_text = QLabel("WASD")
        logo_text.setStyleSheet("color: white; font-size: 24px; font-weight: bold;")
        logo_text.setAlignment(Qt.AlignmentFlag.AlignCenter)
        logo_layout.addWidget(logo_text)
        
        layout.addWidget(logo_frame, alignment=Qt.AlignmentFlag.AlignCenter)
        
        # Description
        desc = QLabel(
            "PhysInput converts your keyboard and mouse input into smooth, "
            "physics-simulated analog gamepad output.\n\n"
            "This wizard will help you set up:\n"
            "• Movement key bindings (WASD)\n"
            "• Button mappings\n"
            "• Physics model selection\n"
            "• Device settings"
        )
        desc.setWordWrap(True)
        desc.setStyleSheet(f"color: {COLORS['text_secondary']}; line-height: 1.5;")
        layout.addWidget(desc)
        
        # Warning about anti-cheat
        warning_frame = QFrame()
        warning_frame.setStyleSheet(f"""
            QFrame {{
                background: {COLORS['warning_bg']};
                border: 1px solid {COLORS['warning']};
                border-radius: 8px;
                padding: 12px;
            }}
        """)
        warning_layout = QVBoxLayout(warning_frame)
        warning_layout.setContentsMargins(12, 12, 12, 12)
        
        warning_title = QLabel("⚠️ Anti-Cheat Notice")
        warning_title.setStyleSheet(f"color: {COLORS['warning']}; font-weight: bold;")
        warning_layout.addWidget(warning_title)
        
        warning_text = QLabel(
            "PhysInput creates a virtual gamepad device. Some anti-cheat software "
            "(like Easy Anti-Cheat or BattlEye) may detect and block virtual input devices. "
            "This tool is intended for accessibility purposes and single-player/non-competitive games. "
            "Use at your own discretion in online games."
        )
        warning_text.setWordWrap(True)
        warning_text.setStyleSheet(f"color: {COLORS['text_secondary']}; font-size: 12px;")
        warning_layout.addWidget(warning_text)
        
        layout.addWidget(warning_frame)
        layout.addStretch()


class MovementKeysPage(QWizardPage):
    """Page for configuring movement keys."""
    
    def __init__(self, config: Config, parent=None):
        super().__init__(parent)
        self.config = config
        
        self.setTitle("Movement Keys")
        self.setSubTitle("Configure the keys that control the left analog stick")
        
        layout = QVBoxLayout(self)
        layout.setSpacing(20)
        
        # Description
        desc = QLabel(
            "These keys will be converted to smooth left stick movement. "
            "Click each button and press the key you want to use."
        )
        desc.setWordWrap(True)
        desc.setStyleSheet(f"color: {COLORS['text_secondary']};")
        layout.addWidget(desc)
        
        # Movement keys widget
        self.movement_widget = MovementKeyWidget()
        self.movement_widget.set_keys(
            self.config.movement_keys.up,
            self.config.movement_keys.down,
            self.config.movement_keys.left,
            self.config.movement_keys.right
        )
        self.movement_widget.keyChanged.connect(self._on_key_changed)
        
        layout.addWidget(self.movement_widget, alignment=Qt.AlignmentFlag.AlignCenter)
        
        # Preset buttons
        presets_layout = QHBoxLayout()
        presets_layout.addStretch()
        
        wasd_btn = QPushButton("WASD")
        wasd_btn.clicked.connect(lambda: self._apply_preset('wasd'))
        presets_layout.addWidget(wasd_btn)
        
        arrows_btn = QPushButton("Arrow Keys")
        arrows_btn.clicked.connect(lambda: self._apply_preset('arrows'))
        presets_layout.addWidget(arrows_btn)
        
        esdf_btn = QPushButton("ESDF")
        esdf_btn.clicked.connect(lambda: self._apply_preset('esdf'))
        presets_layout.addWidget(esdf_btn)
        
        presets_layout.addStretch()
        layout.addLayout(presets_layout)
        
        layout.addStretch()
    
    def _on_key_changed(self, direction: str, key: str):
        """Handle key change."""
        setattr(self.config.movement_keys, direction, key)
    
    def _apply_preset(self, preset: str):
        """Apply a key preset."""
        presets = {
            'wasd': ('w', 's', 'a', 'd'),
            'arrows': ('up', 'down', 'left', 'right'),
            'esdf': ('e', 'd', 's', 'f'),
        }
        
        if preset in presets:
            up, down, left, right = presets[preset]
            self.movement_widget.set_keys(up, down, left, right)
            self.config.movement_keys.up = up
            self.config.movement_keys.down = down
            self.config.movement_keys.left = left
            self.config.movement_keys.right = right


class ButtonBindingsPage(QWizardPage):
    """Page for configuring button bindings."""
    
    def __init__(self, config: Config, parent=None):
        super().__init__(parent)
        self.config = config
        
        self.setTitle("Button Bindings")
        self.setSubTitle("Map keyboard keys to gamepad buttons")
        
        layout = QVBoxLayout(self)
        layout.setSpacing(16)
        
        # Description
        desc = QLabel(
            "Configure which keyboard keys trigger gamepad buttons. "
            "You can add more bindings later in the main application."
        )
        desc.setWordWrap(True)
        desc.setStyleSheet(f"color: {COLORS['text_secondary']};")
        layout.addWidget(desc)
        
        # Common bindings grid
        self.bindings = {}
        
        common_bindings = [
            ("Space", "space", "A (Jump/Confirm)"),
            ("E", "e", "X (Interact)"),
            ("Q", "q", "Y (Alt Action)"),
            ("R", "r", "B (Cancel/Back)"),
            ("Shift", "shift", "LB (L Bumper)"),
            ("Ctrl", "ctrl", "RB (R Bumper)"),
            ("Mouse Left", "mouse_left", "RT (R Trigger)"),
            ("Mouse Right", "mouse_right", "LT (L Trigger)"),
        ]
        
        from PyQt6.QtWidgets import QGridLayout
        grid = QGridLayout()
        grid.setSpacing(12)
        
        for i, (display, key, button_desc) in enumerate(common_bindings):
            row = i // 2
            col = i % 2
            
            frame = QFrame()
            frame.setProperty("class", "card")
            frame.setStyleSheet(f"""
                QFrame {{
                    background: {COLORS['bg_medium']};
                    border: 1px solid {COLORS['border_subtle']};
                    border-radius: 8px;
                    padding: 8px;
                }}
            """)
            
            frame_layout = QHBoxLayout(frame)
            frame_layout.setContentsMargins(12, 8, 12, 8)
            
            checkbox = QCheckBox()
            checkbox.setChecked(False)
            frame_layout.addWidget(checkbox)
            
            text_layout = QVBoxLayout()
            text_layout.setSpacing(2)
            
            key_label = QLabel(display)
            key_label.setStyleSheet(f"color: {COLORS['text_primary']}; font-weight: 500;")
            text_layout.addWidget(key_label)
            
            button_label = QLabel(f"→ {button_desc}")
            button_label.setStyleSheet(f"color: {COLORS['text_muted']}; font-size: 11px;")
            text_layout.addWidget(button_label)
            
            frame_layout.addLayout(text_layout)
            frame_layout.addStretch()
            
            grid.addWidget(frame, row, col)
            
            # Store reference
            self.bindings[key] = (checkbox, self._get_button_code(button_desc))
        
        layout.addLayout(grid)
        
        # Quick preset buttons
        preset_layout = QHBoxLayout()
        preset_layout.addStretch()
        
        fps_btn = QPushButton("FPS Preset")
        fps_btn.clicked.connect(lambda: self._apply_preset('fps'))
        preset_layout.addWidget(fps_btn)
        
        rpg_btn = QPushButton("RPG Preset")
        rpg_btn.clicked.connect(lambda: self._apply_preset('rpg'))
        preset_layout.addWidget(rpg_btn)
        
        none_btn = QPushButton("Clear All")
        none_btn.clicked.connect(lambda: self._apply_preset('none'))
        preset_layout.addWidget(none_btn)
        
        preset_layout.addStretch()
        layout.addLayout(preset_layout)
        
        layout.addStretch()
    
    def _get_button_code(self, desc: str) -> str:
        """Extract button code from description."""
        mapping = {
            "A (Jump/Confirm)": "BTN_SOUTH",
            "X (Interact)": "BTN_WEST",
            "Y (Alt Action)": "BTN_NORTH",
            "B (Cancel/Back)": "BTN_EAST",
            "LB (L Bumper)": "BTN_TL",
            "RB (R Bumper)": "BTN_TR",
            "RT (R Trigger)": "RT",
            "LT (L Trigger)": "LT",
        }
        return mapping.get(desc, "BTN_SOUTH")
    
    def _apply_preset(self, preset: str):
        """Apply a binding preset."""
        if preset == 'none':
            for checkbox, _ in self.bindings.values():
                checkbox.setChecked(False)
        elif preset == 'fps':
            # Enable all for FPS
            for key, (checkbox, _) in self.bindings.items():
                checkbox.setChecked(key in ['space', 'e', 'r', 'shift', 'ctrl', 'mouse_left', 'mouse_right'])
        elif preset == 'rpg':
            # Enable common RPG bindings
            for key, (checkbox, _) in self.bindings.items():
                checkbox.setChecked(key in ['space', 'e', 'q', 'r'])
    
    def validatePage(self) -> bool:
        """Save bindings when leaving page."""
        self.config.button_bindings.clear()
        
        for key, (checkbox, button) in self.bindings.items():
            if checkbox.isChecked():
                self.config.button_bindings[key] = button
        
        return True


class PhysicsModelPage(QWizardPage):
    """Page for selecting physics model."""
    
    def __init__(self, config: Config, parent=None):
        super().__init__(parent)
        self.config = config
        
        self.setTitle("Physics Model")
        self.setSubTitle("Choose how your input feels")
        
        layout = QVBoxLayout(self)
        layout.setSpacing(16)
        
        # Description
        desc = QLabel(
            "PhysInput uses physics simulation to smooth your keyboard input into "
            "natural analog stick movement. Different models feel different:"
        )
        desc.setWordWrap(True)
        desc.setStyleSheet(f"color: {COLORS['text_secondary']};")
        layout.addWidget(desc)
        
        # Model selection
        self.model_list = QListWidget()
        self.model_list.setStyleSheet(f"""
            QListWidget {{
                background: {COLORS['input_bg']};
                border: 1px solid {COLORS['input_border']};
                border-radius: 8px;
            }}
            QListWidget::item {{
                padding: 12px;
                border-bottom: 1px solid {COLORS['border_subtle']};
            }}
            QListWidget::item:selected {{
                background: {COLORS['accent_primary']};
            }}
        """)
        
        models = {
            "spring": ("Spring-Damper", "Responsive with natural bounce. Best for most games."),
            "critical": ("Critically Damped", "Fast response, no overshoot. Good for precision."),
            "smoothdamp": ("Smooth Damp", "Butter-smooth interpolation. Great for cameras."),
            "newtonian": ("Newtonian", "Momentum-based. Feels like pushing through mass."),
            "fluid": ("Fluid", "Like moving through water. Very smooth."),
            "pid": ("PID Controller", "Technical, precise tracking. Highly tunable."),
        }
        
        for model_id, (name, desc) in models.items():
            item = QListWidgetItem(f"{name}\n{desc}")
            item.setData(Qt.ItemDataRole.UserRole, model_id)
            self.model_list.addItem(item)
            
            if model_id == self.config.physics.model:
                item.setSelected(True)
                self.model_list.setCurrentItem(item)
        
        self.model_list.currentItemChanged.connect(self._on_model_changed)
        layout.addWidget(self.model_list)
        
        # Note
        note = QLabel(
            "💡 Tip: You can fine-tune physics parameters in the main application."
        )
        note.setStyleSheet(f"color: {COLORS['text_muted']}; font-size: 12px;")
        layout.addWidget(note)
    
    def _on_model_changed(self, current, previous):
        """Handle model selection change."""
        if current:
            self.config.physics.model = current.data(Qt.ItemDataRole.UserRole)


class DeviceSettingsPage(QWizardPage):
    """Page for device identity settings."""
    
    def __init__(self, config: Config, parent=None):
        super().__init__(parent)
        self.config = config
        
        self.setTitle("Device Settings")
        self.setSubTitle("Configure virtual gamepad identity")
        
        layout = QVBoxLayout(self)
        layout.setSpacing(16)
        
        # Description
        desc = QLabel(
            "PhysInput creates a virtual gamepad. Choose which controller type to emulate. "
            "Some games work better with specific controller types."
        )
        desc.setWordWrap(True)
        desc.setStyleSheet(f"color: {COLORS['text_secondary']};")
        layout.addWidget(desc)
        
        # Device identity
        identity_group = QGroupBox("Controller Type")
        identity_layout = QVBoxLayout(identity_group)
        
        self.identity_combo = QComboBox()
        identities = [
            ("xbox360", "Xbox 360 Controller (recommended)"),
            ("xboxone", "Xbox One Controller"),
            ("xboxsx", "Xbox Series X Controller"),
            ("ds4", "DualShock 4"),
            ("dualsense", "DualSense"),
            ("generic", "Generic Gamepad"),
        ]
        
        for identity_id, name in identities:
            self.identity_combo.addItem(name, identity_id)
            if identity_id == self.config.device.identity:
                self.identity_combo.setCurrentIndex(self.identity_combo.count() - 1)
        
        self.identity_combo.currentIndexChanged.connect(self._on_identity_changed)
        identity_layout.addWidget(self.identity_combo)
        
        layout.addWidget(identity_group)
        
        # Toggle hotkey
        hotkey_group = QGroupBox("Toggle Hotkey")
        hotkey_layout = QHBoxLayout(hotkey_group)
        
        hotkey_label = QLabel("Press to enable/disable PhysInput:")
        hotkey_layout.addWidget(hotkey_label)
        
        self.hotkey_button = KeyCaptureButton(self.config.hotkey)
        self.hotkey_button.keyCaptured.connect(self._on_hotkey_changed)
        hotkey_layout.addWidget(self.hotkey_button)
        hotkey_layout.addStretch()
        
        layout.addWidget(hotkey_group)
        
        layout.addStretch()
    
    def _on_identity_changed(self, index):
        """Handle identity change."""
        self.config.device.identity = self.identity_combo.currentData()
    
    def _on_hotkey_changed(self, key: str):
        """Handle hotkey change."""
        self.config.hotkey = key


class SetupWizard(QWizard):
    """
    First-run setup wizard for PhysInput.
    """
    
    setupComplete = pyqtSignal(Config)
    
    def __init__(self, config: Optional[Config] = None, parent=None):
        super().__init__(parent)
        
        self.config = config or Config()
        
        self.setWindowTitle("PhysInput Setup")
        self.setWizardStyle(QWizard.WizardStyle.ModernStyle)
        self.setMinimumSize(600, 500)
        
        # Apply theme
        self.setStyleSheet(get_wizard_stylesheet())
        
        # Add pages
        self.addPage(WelcomePage())
        self.addPage(MovementKeysPage(self.config))
        self.addPage(ButtonBindingsPage(self.config))
        self.addPage(PhysicsModelPage(self.config))
        self.addPage(DeviceSettingsPage(self.config))
        
        # Connect finish signal
        self.finished.connect(self._on_finished)
    
    def _on_finished(self, result):
        """Handle wizard completion."""
        if result == QWizard.DialogCode.Accepted:
            self.config.first_run_complete = True
            self.setupComplete.emit(self.config)
