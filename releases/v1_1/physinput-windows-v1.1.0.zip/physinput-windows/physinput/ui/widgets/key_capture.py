"""
Key capture widget for rebinding inputs.
"""

from typing import Optional, Callable

from PyQt6.QtWidgets import (
    QWidget, QPushButton, QVBoxLayout, QHBoxLayout, 
    QLabel, QDialog, QFrame
)
from PyQt6.QtCore import Qt, pyqtSignal, QTimer
from PyQt6.QtGui import QKeyEvent, QMouseEvent

from ..theme import COLORS


class KeyCaptureButton(QPushButton):
    """
    Button that captures the next key press for rebinding.
    """
    
    keyCaptured = pyqtSignal(str)  # Emits key name
    
    def __init__(self, current_key: str = "", parent=None):
        super().__init__(parent)
        
        self._current_key = current_key
        self._capturing = False
        self._original_text = ""
        
        self.setMinimumWidth(80)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        
        self._update_display()
        self.clicked.connect(self._start_capture)
    
    def _update_display(self):
        """Update button text."""
        if self._capturing:
            self.setText("Press key...")
            self.setStyleSheet(f"""
                QPushButton {{
                    background-color: {COLORS['accent_primary']};
                    border: 2px solid {COLORS['accent_secondary']};
                    color: white;
                }}
            """)
        else:
            display = self._current_key.upper() if self._current_key else "None"
            self.setText(display)
            self.setStyleSheet("")
    
    def _start_capture(self):
        """Start capturing key input."""
        self._capturing = True
        self._original_text = self._current_key
        self._update_display()
        self.setFocus()
    
    def _stop_capture(self, new_key: Optional[str] = None):
        """Stop capturing and optionally set new key."""
        self._capturing = False
        
        if new_key is not None:
            self._current_key = new_key
            self.keyCaptured.emit(new_key)
        
        self._update_display()
    
    def keyPressEvent(self, event: QKeyEvent):
        """Handle key press during capture."""
        if not self._capturing:
            super().keyPressEvent(event)
            return
        
        # Cancel on Escape
        if event.key() == Qt.Key.Key_Escape:
            self._stop_capture()
            return
        
        # Get key name
        key_name = self._qt_key_to_name(event.key())
        if key_name:
            self._stop_capture(key_name)
    
    def mousePressEvent(self, event: QMouseEvent):
        """Handle mouse button during capture."""
        if not self._capturing:
            super().mousePressEvent(event)
            return
        
        # Map mouse buttons
        button_map = {
            Qt.MouseButton.LeftButton: "mouse_left",
            Qt.MouseButton.RightButton: "mouse_right",
            Qt.MouseButton.MiddleButton: "mouse_middle",
            Qt.MouseButton.BackButton: "mouse_4",
            Qt.MouseButton.ForwardButton: "mouse_5",
        }
        
        if event.button() in button_map:
            self._stop_capture(button_map[event.button()])
    
    def focusOutEvent(self, event):
        """Cancel capture on focus loss."""
        if self._capturing:
            self._stop_capture()
        super().focusOutEvent(event)
    
    def _qt_key_to_name(self, qt_key: int) -> Optional[str]:
        """Convert Qt key code to simple name."""
        # Common keys mapping
        key_map = {
            Qt.Key.Key_A: 'a', Qt.Key.Key_B: 'b', Qt.Key.Key_C: 'c',
            Qt.Key.Key_D: 'd', Qt.Key.Key_E: 'e', Qt.Key.Key_F: 'f',
            Qt.Key.Key_G: 'g', Qt.Key.Key_H: 'h', Qt.Key.Key_I: 'i',
            Qt.Key.Key_J: 'j', Qt.Key.Key_K: 'k', Qt.Key.Key_L: 'l',
            Qt.Key.Key_M: 'm', Qt.Key.Key_N: 'n', Qt.Key.Key_O: 'o',
            Qt.Key.Key_P: 'p', Qt.Key.Key_Q: 'q', Qt.Key.Key_R: 'r',
            Qt.Key.Key_S: 's', Qt.Key.Key_T: 't', Qt.Key.Key_U: 'u',
            Qt.Key.Key_V: 'v', Qt.Key.Key_W: 'w', Qt.Key.Key_X: 'x',
            Qt.Key.Key_Y: 'y', Qt.Key.Key_Z: 'z',
            Qt.Key.Key_0: '0', Qt.Key.Key_1: '1', Qt.Key.Key_2: '2',
            Qt.Key.Key_3: '3', Qt.Key.Key_4: '4', Qt.Key.Key_5: '5',
            Qt.Key.Key_6: '6', Qt.Key.Key_7: '7', Qt.Key.Key_8: '8',
            Qt.Key.Key_9: '9',
            Qt.Key.Key_F1: 'f1', Qt.Key.Key_F2: 'f2', Qt.Key.Key_F3: 'f3',
            Qt.Key.Key_F4: 'f4', Qt.Key.Key_F5: 'f5', Qt.Key.Key_F6: 'f6',
            Qt.Key.Key_F7: 'f7', Qt.Key.Key_F8: 'f8', Qt.Key.Key_F9: 'f9',
            Qt.Key.Key_F10: 'f10', Qt.Key.Key_F11: 'f11', Qt.Key.Key_F12: 'f12',
            Qt.Key.Key_Space: 'space',
            Qt.Key.Key_Return: 'enter', Qt.Key.Key_Enter: 'enter',
            Qt.Key.Key_Tab: 'tab',
            Qt.Key.Key_Backspace: 'backspace',
            Qt.Key.Key_Delete: 'delete',
            Qt.Key.Key_Insert: 'insert',
            Qt.Key.Key_Home: 'home', Qt.Key.Key_End: 'end',
            Qt.Key.Key_PageUp: 'pageup', Qt.Key.Key_PageDown: 'pagedown',
            Qt.Key.Key_Up: 'up', Qt.Key.Key_Down: 'down',
            Qt.Key.Key_Left: 'left', Qt.Key.Key_Right: 'right',
            Qt.Key.Key_Shift: 'shift',
            Qt.Key.Key_Control: 'ctrl',
            Qt.Key.Key_Alt: 'alt',
            Qt.Key.Key_Meta: 'super',
            Qt.Key.Key_CapsLock: 'capslock',
            Qt.Key.Key_NumLock: 'numlock',
            Qt.Key.Key_Pause: 'pause',
            Qt.Key.Key_Print: 'print',
            Qt.Key.Key_Minus: 'minus', Qt.Key.Key_Equal: 'equal',
            Qt.Key.Key_BracketLeft: 'leftbracket',
            Qt.Key.Key_BracketRight: 'rightbracket',
            Qt.Key.Key_Backslash: 'backslash',
            Qt.Key.Key_Semicolon: 'semicolon',
            Qt.Key.Key_Apostrophe: 'apostrophe',
            Qt.Key.Key_QuoteLeft: 'grave',
            Qt.Key.Key_Comma: 'comma',
            Qt.Key.Key_Period: 'period',
            Qt.Key.Key_Slash: 'slash',
        }
        
        return key_map.get(qt_key)
    
    @property
    def current_key(self) -> str:
        return self._current_key
    
    @current_key.setter
    def current_key(self, value: str):
        self._current_key = value
        self._update_display()


class MovementKeyWidget(QFrame):
    """
    Visual WASD-style movement key binder.
    """
    
    keyChanged = pyqtSignal(str, str)  # direction, new_key
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self._keys = {
            'up': 'w',
            'down': 's', 
            'left': 'a',
            'right': 'd'
        }
        
        self._buttons = {}
        self._setup_ui()
    
    def _setup_ui(self):
        """Setup the WASD layout."""
        self.setProperty("class", "card")
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(8)
        
        # Title
        title = QLabel("Movement Keys")
        title.setProperty("class", "subheading")
        layout.addWidget(title, alignment=Qt.AlignmentFlag.AlignCenter)
        
        # Key grid
        from PyQt6.QtWidgets import QGridLayout
        grid = QGridLayout()
        grid.setSpacing(4)
        
        # Up key (row 0, col 1)
        self._buttons['up'] = KeyCaptureButton(self._keys['up'])
        self._buttons['up'].keyCaptured.connect(lambda k: self._on_key_changed('up', k))
        grid.addWidget(self._buttons['up'], 0, 1)
        
        # Left, Down, Right (row 1)
        self._buttons['left'] = KeyCaptureButton(self._keys['left'])
        self._buttons['left'].keyCaptured.connect(lambda k: self._on_key_changed('left', k))
        grid.addWidget(self._buttons['left'], 1, 0)
        
        self._buttons['down'] = KeyCaptureButton(self._keys['down'])
        self._buttons['down'].keyCaptured.connect(lambda k: self._on_key_changed('down', k))
        grid.addWidget(self._buttons['down'], 1, 1)
        
        self._buttons['right'] = KeyCaptureButton(self._keys['right'])
        self._buttons['right'].keyCaptured.connect(lambda k: self._on_key_changed('right', k))
        grid.addWidget(self._buttons['right'], 1, 2)
        
        layout.addLayout(grid)
    
    def _on_key_changed(self, direction: str, new_key: str):
        """Handle key change."""
        self._keys[direction] = new_key
        self.keyChanged.emit(direction, new_key)
    
    def set_keys(self, up: str, down: str, left: str, right: str):
        """Set all movement keys."""
        self._keys = {'up': up, 'down': down, 'left': left, 'right': right}
        
        for direction, key in self._keys.items():
            self._buttons[direction].current_key = key
    
    def get_keys(self) -> dict:
        """Get current key bindings."""
        return dict(self._keys)


class BindingEditorDialog(QDialog):
    """
    Dialog for editing a button binding.
    """
    
    def __init__(self, key: str = "", button: str = "", parent=None):
        super().__init__(parent)
        
        self.setWindowTitle("Edit Binding")
        self.setModal(True)
        self.setMinimumWidth(300)
        
        self._key = key
        self._button = button
        
        self._setup_ui()
    
    def _setup_ui(self):
        """Setup dialog UI."""
        layout = QVBoxLayout(self)
        layout.setSpacing(16)
        
        # Key input
        key_layout = QHBoxLayout()
        key_layout.addWidget(QLabel("Input Key:"))
        self.key_button = KeyCaptureButton(self._key)
        key_layout.addWidget(self.key_button)
        layout.addLayout(key_layout)
        
        # Button selection
        button_layout = QHBoxLayout()
        button_layout.addWidget(QLabel("Controller Button:"))
        
        from PyQt6.QtWidgets import QComboBox
        self.button_combo = QComboBox()
        
        # Common button options
        buttons = [
            ("A (BTN_SOUTH)", "BTN_SOUTH"),
            ("B (BTN_EAST)", "BTN_EAST"),
            ("X (BTN_WEST)", "BTN_WEST"),
            ("Y (BTN_NORTH)", "BTN_NORTH"),
            ("LB (BTN_TL)", "BTN_TL"),
            ("RB (BTN_TR)", "BTN_TR"),
            ("Left Trigger (LT)", "LT"),
            ("Right Trigger (RT)", "RT"),
            ("Back/Select", "BTN_SELECT"),
            ("Start/Menu", "BTN_START"),
            ("Guide/Xbox", "BTN_MODE"),
            ("L3 (Left Stick)", "BTN_THUMBL"),
            ("R3 (Right Stick)", "BTN_THUMBR"),
            ("D-Pad Up", "DPAD_UP"),
            ("D-Pad Down", "DPAD_DOWN"),
            ("D-Pad Left", "DPAD_LEFT"),
            ("D-Pad Right", "DPAD_RIGHT"),
        ]
        
        for display, value in buttons:
            self.button_combo.addItem(display, value)
        
        # Set current value
        for i in range(self.button_combo.count()):
            if self.button_combo.itemData(i) == self._button:
                self.button_combo.setCurrentIndex(i)
                break
        
        button_layout.addWidget(self.button_combo)
        layout.addLayout(button_layout)
        
        # Dialog buttons
        from PyQt6.QtWidgets import QDialogButtonBox
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | 
            QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
    
    def get_binding(self) -> tuple:
        """Get the configured binding."""
        return (
            self.key_button.current_key,
            self.button_combo.currentData()
        )
