"""
Real-time graph widget for input visualization.
"""

from collections import deque
from typing import List, Tuple, Optional

from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel, QHBoxLayout
from PyQt6.QtCore import Qt, QPointF, QRectF
from PyQt6.QtGui import QPainter, QPen, QBrush, QColor, QPainterPath, QLinearGradient

from ..theme import COLORS, GraphColors


class GraphWidget(QWidget):
    """
    Real-time scrolling graph for visualizing input over time.
    """
    
    def __init__(self, title: str = "", max_points: int = 100, parent=None):
        super().__init__(parent)
        
        self.title = title
        self.max_points = max_points
        
        # Data series (can have multiple)
        self._series: List[Tuple[str, deque, str]] = []  # (name, data, color)
        
        # Display range
        self._y_min = -1.0
        self._y_max = 1.0
        self._auto_scale = False
        
        # Colors
        self.colors = GraphColors()
        
        # Size
        self.setMinimumSize(200, 80)
        
        self._setup_ui()
    
    def _setup_ui(self):
        """Setup the widget UI."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(2)
        
        # Header with title and legend
        header = QHBoxLayout()
        header.setSpacing(12)
        
        if self.title:
            title_label = QLabel(self.title)
            title_label.setStyleSheet(f"color: {COLORS['text_secondary']}; font-size: 11px;")
            header.addWidget(title_label)
        
        header.addStretch()
        
        # Legend will be added dynamically
        self.legend_layout = QHBoxLayout()
        self.legend_layout.setSpacing(8)
        header.addLayout(self.legend_layout)
        
        layout.addLayout(header)
        layout.addStretch()
    
    def add_series(self, name: str, color: str = None):
        """Add a data series to the graph."""
        if color is None:
            # Auto-assign colors
            palette = [
                COLORS['accent_primary'],
                COLORS['success'],
                COLORS['warning'],
                COLORS['error'],
            ]
            color = palette[len(self._series) % len(palette)]
        
        self._series.append((name, deque(maxlen=self.max_points), color))
        
        # Add legend entry
        legend_item = QLabel(f"● {name}")
        legend_item.setStyleSheet(f"color: {color}; font-size: 10px;")
        self.legend_layout.addWidget(legend_item)
    
    def add_value(self, series_index: int, value: float):
        """Add a value to a series."""
        if 0 <= series_index < len(self._series):
            self._series[series_index][1].append(value)
            
            if self._auto_scale:
                self._update_scale()
            
            self.update()
    
    def add_values(self, values: List[float]):
        """Add values to all series at once."""
        for i, value in enumerate(values):
            if i < len(self._series):
                self._series[i][1].append(value)
        
        if self._auto_scale:
            self._update_scale()
        
        self.update()
    
    def set_range(self, y_min: float, y_max: float):
        """Set the Y-axis range."""
        self._y_min = y_min
        self._y_max = y_max
        self._auto_scale = False
        self.update()
    
    def set_auto_scale(self, enabled: bool):
        """Enable/disable auto-scaling."""
        self._auto_scale = enabled
        if enabled:
            self._update_scale()
    
    def _update_scale(self):
        """Update Y-axis scale based on data."""
        min_val = 0
        max_val = 0
        
        for _, data, _ in self._series:
            if data:
                min_val = min(min_val, min(data))
                max_val = max(max_val, max(data))
        
        # Add padding
        padding = (max_val - min_val) * 0.1 or 0.1
        self._y_min = min_val - padding
        self._y_max = max_val + padding
    
    def clear(self):
        """Clear all data."""
        for _, data, _ in self._series:
            data.clear()
        self.update()
    
    def paintEvent(self, event):
        """Paint the graph."""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        rect = self.rect()
        
        # Drawing area (leave margins)
        margin_left = 40
        margin_right = 10
        margin_top = 25
        margin_bottom = 20
        
        graph_rect = QRectF(
            margin_left, margin_top,
            rect.width() - margin_left - margin_right,
            rect.height() - margin_top - margin_bottom
        )
        
        # Background
        painter.fillRect(graph_rect, QColor(self.colors.background))
        
        # Draw grid
        self._draw_grid(painter, graph_rect)
        
        # Draw Y-axis labels
        self._draw_axis_labels(painter, graph_rect)
        
        # Draw each series
        for name, data, color in self._series:
            if len(data) > 1:
                self._draw_series(painter, graph_rect, data, color)
        
        # Border
        painter.setPen(QPen(QColor(self.colors.axis), 1))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawRect(graph_rect)
    
    def _draw_grid(self, painter: QPainter, rect: QRectF):
        """Draw background grid."""
        painter.setPen(QPen(QColor(self.colors.grid), 1))
        
        # Horizontal lines (5 divisions)
        for i in range(1, 5):
            y = rect.top() + (rect.height() / 5) * i
            painter.drawLine(int(rect.left()), int(y), int(rect.right()), int(y))
        
        # Zero line if in range
        if self._y_min < 0 < self._y_max:
            zero_y = rect.bottom() - (0 - self._y_min) / (self._y_max - self._y_min) * rect.height()
            painter.setPen(QPen(QColor(self.colors.axis), 1))
            painter.drawLine(int(rect.left()), int(zero_y), int(rect.right()), int(zero_y))
    
    def _draw_axis_labels(self, painter: QPainter, rect: QRectF):
        """Draw Y-axis labels."""
        painter.setPen(QPen(QColor(self.colors.text)))
        font = painter.font()
        font.setPointSize(8)
        painter.setFont(font)
        
        # Top label
        painter.drawText(
            int(rect.left() - 35), int(rect.top() - 5),
            30, 15,
            Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter,
            f"{self._y_max:.1f}"
        )
        
        # Bottom label
        painter.drawText(
            int(rect.left() - 35), int(rect.bottom() - 10),
            30, 15,
            Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter,
            f"{self._y_min:.1f}"
        )
        
        # Zero label if in range
        if self._y_min < 0 < self._y_max:
            zero_y = rect.bottom() - (0 - self._y_min) / (self._y_max - self._y_min) * rect.height()
            painter.drawText(
                int(rect.left() - 35), int(zero_y - 7),
                30, 15,
                Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter,
                "0"
            )
    
    def _draw_series(self, painter: QPainter, rect: QRectF, data: deque, color: str):
        """Draw a data series."""
        if len(data) < 2:
            return
        
        points = []
        for i, value in enumerate(data):
            x = rect.left() + (i / (self.max_points - 1)) * rect.width()
            y = rect.bottom() - ((value - self._y_min) / (self._y_max - self._y_min)) * rect.height()
            points.append(QPointF(x, y))
        
        # Draw filled area
        fill_path = QPainterPath()
        fill_path.moveTo(points[0].x(), rect.bottom())
        for point in points:
            fill_path.lineTo(point)
        fill_path.lineTo(points[-1].x(), rect.bottom())
        fill_path.closeSubpath()
        
        gradient = QLinearGradient(0, rect.top(), 0, rect.bottom())
        fill_color = QColor(color)
        fill_color.setAlpha(40)
        gradient.setColorAt(0, fill_color)
        fill_color.setAlpha(5)
        gradient.setColorAt(1, fill_color)
        
        painter.fillPath(fill_path, gradient)
        
        # Draw line
        line_path = QPainterPath()
        line_path.moveTo(points[0])
        for point in points[1:]:
            line_path.lineTo(point)
        
        painter.setPen(QPen(QColor(color), 2))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawPath(line_path)


class InputGraphsWidget(QWidget):
    """
    Widget containing multiple graphs for comprehensive input visualization.
    """
    
    def __init__(self, max_points: int = 100, parent=None):
        super().__init__(parent)
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)
        
        # Left stick graph
        self.left_graph = GraphWidget("Left Stick", max_points)
        self.left_graph.add_series("X", COLORS['accent_primary'])
        self.left_graph.add_series("Y", COLORS['success'])
        self.left_graph.set_range(-1.0, 1.0)
        layout.addWidget(self.left_graph)
        
        # Right stick graph
        self.right_graph = GraphWidget("Right Stick", max_points)
        self.right_graph.add_series("X", COLORS['accent_primary'])
        self.right_graph.add_series("Y", COLORS['success'])
        self.right_graph.set_range(-1.0, 1.0)
        layout.addWidget(self.right_graph)
        
        # Mouse velocity graph
        self.velocity_graph = GraphWidget("Mouse Velocity", max_points)
        self.velocity_graph.add_series("Speed", COLORS['warning'])
        self.velocity_graph.set_range(0, 2000)
        self.velocity_graph.set_auto_scale(True)
        layout.addWidget(self.velocity_graph)
    
    def update_values(self, left: Tuple[float, float], right: Tuple[float, float], 
                      velocity: float):
        """Update all graphs with new values."""
        self.left_graph.add_values([left[0], left[1]])
        self.right_graph.add_values([right[0], right[1]])
        self.velocity_graph.add_value(0, velocity)
    
    def clear(self):
        """Clear all graphs."""
        self.left_graph.clear()
        self.right_graph.clear()
        self.velocity_graph.clear()
