#!/usr/bin/env python3
"""
PhysInput for Linux - Main entry point.
"""

import sys
import os
import argparse


def check_permissions():
    """Check if user has required permissions."""
    if os.geteuid() == 0:
        return True
    try:
        import grp
        if grp.getgrnam('input').gr_gid in os.getgroups():
            return True
    except (KeyError, ImportError):
        pass
    return False


def main():
    parser = argparse.ArgumentParser(description="PhysInput - Physics-based analog input for Linux")
    parser.add_argument('--check', action='store_true', help="Check system requirements")
    parser.add_argument('--profile', type=str, help="Load a profile on startup")
    parser.add_argument('--version', action='store_true', help="Show version")
    args = parser.parse_args()
    
    from physinput import __version__
    
    if args.version:
        print(f"PhysInput {__version__} (Linux)")
        sys.exit(0)
    
    # Check dependencies
    missing = []
    try:
        import evdev
    except ImportError:
        missing.append("evdev")
    try:
        from PyQt6.QtWidgets import QApplication
    except ImportError:
        missing.append("PyQt6")
    
    if args.check:
        print("PhysInput System Check (Linux)")
        print("=" * 40)
        print(f"Dependencies: {'OK' if not missing else 'MISSING'}")
        if missing:
            for m in missing:
                print(f"  - {m}")
        print(f"Permissions: {'OK' if check_permissions() else 'Need input group'}")
        
        if not check_permissions():
            print("\nAdd user to input group:")
            print("  sudo usermod -aG input $USER")
            print("  (then log out and back in)")
        
        if not missing:
            try:
                from evdev import list_devices, InputDevice
                devs = list_devices()
                print(f"\nInput devices: {len(devs)}")
                for p in devs[:5]:
                    try:
                        d = InputDevice(p)
                        print(f"  - {d.name}")
                        d.close()
                    except: pass
            except Exception as e:
                print(f"\nCould not list devices: {e}")
        
        sys.exit(0 if not missing else 1)
    
    if missing:
        print("Missing dependencies:")
        for m in missing:
            print(f"  - {m}")
        print("\nInstall with:")
        print("  pip install evdev PyQt6 --break-system-packages")
        sys.exit(1)
    
    if not check_permissions():
        print("⚠ Warning: Not in 'input' group")
        print("  Run: sudo usermod -aG input $USER")
    
    # Start GUI
    from PyQt6.QtWidgets import QApplication
    from PyQt6.QtCore import Qt
    from PyQt6.QtGui import QFont
    
    QApplication.setHighDpiScaleFactorRoundingPolicy(
        Qt.HighDpiScaleFactorRoundingPolicy.PassThrough
    )
    
    app = QApplication(sys.argv)
    app.setApplicationName("PhysInput")
    
    font = QFont("Inter", 10)
    if not font.exactMatch():
        font = QFont("Ubuntu", 10)
    app.setFont(font)
    
    config = None
    if args.profile:
        from physinput.core import load_profile
        config = load_profile(args.profile)
    
    from physinput.ui import MainWindow
    window = MainWindow()
    if config:
        window._load_profile(config)
    window.show()
    
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
