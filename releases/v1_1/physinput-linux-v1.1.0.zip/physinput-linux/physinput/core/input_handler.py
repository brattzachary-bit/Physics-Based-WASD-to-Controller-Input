"""
Linux input handler using evdev.
Captures keyboard and mouse input at the kernel level.
"""

import time
import threading
from typing import Optional, List, Tuple, Dict, Callable
from dataclasses import dataclass, field
from collections import deque

import evdev
from evdev import InputDevice, ecodes, list_devices


# Key name mappings
KEY_NAMES = {
    'a': 'KEY_A', 'b': 'KEY_B', 'c': 'KEY_C', 'd': 'KEY_D', 'e': 'KEY_E',
    'f': 'KEY_F', 'g': 'KEY_G', 'h': 'KEY_H', 'i': 'KEY_I', 'j': 'KEY_J',
    'k': 'KEY_K', 'l': 'KEY_L', 'm': 'KEY_M', 'n': 'KEY_N', 'o': 'KEY_O',
    'p': 'KEY_P', 'q': 'KEY_Q', 'r': 'KEY_R', 's': 'KEY_S', 't': 'KEY_T',
    'u': 'KEY_U', 'v': 'KEY_V', 'w': 'KEY_W', 'x': 'KEY_X', 'y': 'KEY_Y',
    'z': 'KEY_Z',
    '1': 'KEY_1', '2': 'KEY_2', '3': 'KEY_3', '4': 'KEY_4', '5': 'KEY_5',
    '6': 'KEY_6', '7': 'KEY_7', '8': 'KEY_8', '9': 'KEY_9', '0': 'KEY_0',
    'f1': 'KEY_F1', 'f2': 'KEY_F2', 'f3': 'KEY_F3', 'f4': 'KEY_F4',
    'f5': 'KEY_F5', 'f6': 'KEY_F6', 'f7': 'KEY_F7', 'f8': 'KEY_F8',
    'f9': 'KEY_F9', 'f10': 'KEY_F10', 'f11': 'KEY_F11', 'f12': 'KEY_F12',
    'shift': 'KEY_LEFTSHIFT', 'lshift': 'KEY_LEFTSHIFT', 'rshift': 'KEY_RIGHTSHIFT',
    'ctrl': 'KEY_LEFTCTRL', 'lctrl': 'KEY_LEFTCTRL', 'rctrl': 'KEY_RIGHTCTRL',
    'alt': 'KEY_LEFTALT', 'lalt': 'KEY_LEFTALT', 'ralt': 'KEY_RIGHTALT',
    'super': 'KEY_LEFTMETA', 'meta': 'KEY_LEFTMETA',
    'space': 'KEY_SPACE', 'enter': 'KEY_ENTER', 'return': 'KEY_ENTER',
    'tab': 'KEY_TAB', 'backspace': 'KEY_BACKSPACE', 'delete': 'KEY_DELETE',
    'escape': 'KEY_ESC', 'esc': 'KEY_ESC',
    'insert': 'KEY_INSERT', 'home': 'KEY_HOME', 'end': 'KEY_END',
    'pageup': 'KEY_PAGEUP', 'pagedown': 'KEY_PAGEDOWN',
    'up': 'KEY_UP', 'down': 'KEY_DOWN', 'left': 'KEY_LEFT', 'right': 'KEY_RIGHT',
    'capslock': 'KEY_CAPSLOCK', 'numlock': 'KEY_NUMLOCK',
    'pause': 'KEY_PAUSE', 'print': 'KEY_PRINT', 'scrolllock': 'KEY_SCROLLLOCK',
    'minus': 'KEY_MINUS', 'equal': 'KEY_EQUAL',
    'comma': 'KEY_COMMA', 'period': 'KEY_DOT', 'slash': 'KEY_SLASH',
    'mouse_left': 'BTN_LEFT', 'mouse_right': 'BTN_RIGHT', 'mouse_middle': 'BTN_MIDDLE',
    'mouse_4': 'BTN_SIDE', 'mouse_5': 'BTN_EXTRA',
}

EVDEV_TO_NAME = {v: k for k, v in KEY_NAMES.items()}


def get_evdev_code(key_name: str) -> Optional[int]:
    """Convert a key name to evdev code."""
    key_lower = key_name.lower()
    if key_lower in KEY_NAMES:
        evdev_name = KEY_NAMES[key_lower]
        return getattr(ecodes, evdev_name, None)
    if key_name.startswith('KEY_') or key_name.startswith('BTN_'):
        return getattr(ecodes, key_name, None)
    return getattr(ecodes, f'KEY_{key_name.upper()}', None)


def get_key_name(evdev_code: int) -> str:
    """Convert evdev code to human-readable name."""
    evdev_name = ecodes.KEY.get(evdev_code) or ecodes.BTN.get(evdev_code)
    if evdev_name:
        if isinstance(evdev_name, list):
            evdev_name = evdev_name[0]
        if evdev_name in EVDEV_TO_NAME:
            return EVDEV_TO_NAME[evdev_name]
        return evdev_name.replace('KEY_', '').replace('BTN_', '').lower()
    return f'code_{evdev_code}'


@dataclass
class MouseState:
    """Current mouse state."""
    x: float = 0.0
    y: float = 0.0
    velocity_x: float = 0.0
    velocity_y: float = 0.0
    buttons: Dict[str, bool] = field(default_factory=dict)


@dataclass
class KeyboardState:
    """Current keyboard state."""
    keys: Dict[str, bool] = field(default_factory=dict)


class InputHandler:
    """Handles input capture from keyboard and mouse via evdev."""
    
    def __init__(self):
        self.keyboard_state = KeyboardState()
        self.mouse_state = MouseState()
        
        self._devices: List[InputDevice] = []
        self._running = False
        self._thread: Optional[threading.Thread] = None
        
        self._last_mouse_time = time.time()
        self._mouse_accumulator = [0.0, 0.0]
        self._velocity_history: deque = deque(maxlen=10)
        
        # Callbacks
        self.on_key_event: Optional[Callable[[str, bool], None]] = None
        self.on_mouse_move: Optional[Callable[[float, float], None]] = None
        self.on_mouse_button: Optional[Callable[[str, bool], None]] = None
    
    def start(self) -> bool:
        """Start capturing input."""
        if self._running:
            return True
        
        # Auto-detect devices
        for path in list_devices():
            try:
                device = InputDevice(path)
                caps = device.capabilities()
                
                if ecodes.EV_KEY in caps:
                    key_caps = caps[ecodes.EV_KEY]
                    if ecodes.KEY_A in key_caps or ecodes.BTN_LEFT in key_caps:
                        self._devices.append(device)
                
                if ecodes.EV_REL in caps and device not in self._devices:
                    rel_caps = caps[ecodes.EV_REL]
                    if ecodes.REL_X in rel_caps:
                        self._devices.append(device)
                        
            except (PermissionError, OSError):
                continue
        
        if not self._devices:
            return False
        
        self._running = True
        self._thread = threading.Thread(target=self._input_loop, daemon=True)
        self._thread.start()
        
        return True
    
    def stop(self):
        """Stop capturing input."""
        self._running = False
        
        if self._thread:
            self._thread.join(timeout=1.0)
            self._thread = None
        
        for device in self._devices:
            try:
                device.close()
            except Exception:
                pass
        
        self._devices.clear()
    
    def is_key_pressed(self, key: str) -> bool:
        """Check if a key is currently pressed."""
        return self.keyboard_state.keys.get(key.lower(), False)
    
    def get_mouse_velocity(self) -> Tuple[float, float]:
        """Get current mouse velocity."""
        return (self.mouse_state.velocity_x, self.mouse_state.velocity_y)
    
    def get_smoothed_velocity(self, frames: int = 3) -> Tuple[float, float]:
        """Get smoothed mouse velocity."""
        if not self._velocity_history:
            return (0.0, 0.0)
        
        history = list(self._velocity_history)[-frames:]
        if not history:
            return (0.0, 0.0)
        
        avg_x = sum(v[0] for v in history) / len(history)
        avg_y = sum(v[1] for v in history) / len(history)
        
        return (avg_x, avg_y)
    
    def _input_loop(self):
        """Main input capture loop."""
        import select
        
        while self._running and self._devices:
            try:
                r, _, _ = select.select(self._devices, [], [], 0.01)
                current_time = time.time()
                
                for device in r:
                    try:
                        for event in device.read():
                            self._handle_event(event, current_time)
                    except (BlockingIOError, OSError):
                        continue
                
                self._update_mouse_velocity(current_time)
                
            except Exception as e:
                if self._running:
                    time.sleep(0.1)
    
    def _handle_event(self, event, current_time: float):
        """Handle a single input event."""
        if event.type == ecodes.EV_KEY:
            self._handle_key_event(event)
        elif event.type == ecodes.EV_REL:
            self._handle_rel_event(event)
    
    def _handle_key_event(self, event):
        """Handle keyboard/button event."""
        code = event.code
        pressed = event.value > 0
        
        key_name = get_key_name(code)
        
        if code in (ecodes.BTN_LEFT, ecodes.BTN_RIGHT, ecodes.BTN_MIDDLE,
                    ecodes.BTN_SIDE, ecodes.BTN_EXTRA):
            self.mouse_state.buttons[key_name] = pressed
            if self.on_mouse_button:
                self.on_mouse_button(key_name, pressed)
        else:
            self.keyboard_state.keys[key_name] = pressed
            if self.on_key_event:
                self.on_key_event(key_name, pressed)
    
    def _handle_rel_event(self, event):
        """Handle relative mouse movement."""
        if event.code == ecodes.REL_X:
            self._mouse_accumulator[0] += event.value
        elif event.code == ecodes.REL_Y:
            self._mouse_accumulator[1] += event.value
    
    def _update_mouse_velocity(self, current_time: float):
        """Update mouse velocity from accumulated movement."""
        dt = current_time - self._last_mouse_time
        
        if dt >= 0.001:
            vel_x = self._mouse_accumulator[0] / dt
            vel_y = self._mouse_accumulator[1] / dt
            
            self.mouse_state.x = self._mouse_accumulator[0]
            self.mouse_state.y = self._mouse_accumulator[1]
            self.mouse_state.velocity_x = vel_x
            self.mouse_state.velocity_y = vel_y
            
            self._velocity_history.append((vel_x, vel_y))
            
            if self.on_mouse_move and (self.mouse_state.x != 0 or self.mouse_state.y != 0):
                self.on_mouse_move(self.mouse_state.x, self.mouse_state.y)
            
            self._mouse_accumulator = [0.0, 0.0]
            self._last_mouse_time = current_time
    
    def clear_state(self):
        """Clear all input state."""
        self.keyboard_state.keys.clear()
        self.mouse_state.buttons.clear()
        self.mouse_state.x = 0
        self.mouse_state.y = 0
        self.mouse_state.velocity_x = 0
        self.mouse_state.velocity_y = 0
