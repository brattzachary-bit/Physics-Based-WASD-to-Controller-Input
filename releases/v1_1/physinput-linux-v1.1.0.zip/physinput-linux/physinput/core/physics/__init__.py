"""
Physics models for analog stick simulation.
"""

from typing import Dict, Type

from .base import PhysicsModel, PhysicsState
from .spring import SpringModel, CriticallyDampedSpring
from .newtonian import NewtonianModel, MomentumModel
from .pid import PIDModel, AdaptivePIDModel
from .fluid import FluidModel, SmoothDampModel, ExponentialModel


# Registry of all available physics models
PHYSICS_MODELS: Dict[str, Type[PhysicsModel]] = {
    "spring": SpringModel,
    "critical": CriticallyDampedSpring,
    "newtonian": NewtonianModel,
    "momentum": MomentumModel,
    "pid": PIDModel,
    "adaptive_pid": AdaptivePIDModel,
    "fluid": FluidModel,
    "smoothdamp": SmoothDampModel,
    "exponential": ExponentialModel,
}


def get_model(name: str) -> PhysicsModel:
    """Get a physics model instance by name."""
    if name not in PHYSICS_MODELS:
        raise ValueError(f"Unknown physics model: {name}. Available: {list(PHYSICS_MODELS.keys())}")
    return PHYSICS_MODELS[name]()


def list_models() -> Dict[str, str]:
    """Get dict of model names to descriptions."""
    return {
        name: cls.description 
        for name, cls in PHYSICS_MODELS.items()
    }


__all__ = [
    "PhysicsModel",
    "PhysicsState",
    "SpringModel",
    "CriticallyDampedSpring",
    "NewtonianModel",
    "MomentumModel",
    "PIDModel",
    "AdaptivePIDModel",
    "FluidModel",
    "SmoothDampModel",
    "ExponentialModel",
    "PHYSICS_MODELS",
    "get_model",
    "list_models",
]
