"""
PID controller physics model.
Uses proportional-integral-derivative control for precise tracking.
"""

import math
from typing import Tuple, Dict, Any

from .base import PhysicsModel


class PIDModel(PhysicsModel):
    """
    PID controller for precise target tracking.
    
    output = Kp*error + Ki*integral(error) + Kd*derivative(error)
    
    Good for: Precise, consistent tracking with minimal overshoot
    """
    
    name = "pid"
    description = "PID controller for precise, tunable target tracking"
    
    @property
    def default_params(self) -> Dict[str, Any]:
        return {
            "kp": 10.0,              # Proportional gain
            "ki": 0.5,               # Integral gain
            "kd": 2.0,               # Derivative gain
            "integral_limit": 1.0,   # Anti-windup limit
            "output_smoothing": 0.0, # Additional output smoothing
        }
    
    @property
    def param_ranges(self) -> Dict[str, Tuple[float, float, float]]:
        return {
            "kp": (0.1, 50.0, 0.1),
            "ki": (0.0, 5.0, 0.05),
            "kd": (0.0, 10.0, 0.1),
            "integral_limit": (0.1, 5.0, 0.1),
            "output_smoothing": (0.0, 0.99, 0.01),
        }
    
    def __init__(self):
        super().__init__()
        self._params = self.default_params.copy()
        self._integral = [0.0, 0.0]
        self._last_error = [0.0, 0.0]
        self._output = [0.0, 0.0]
    
    def reset(self):
        """Reset PID state."""
        super().reset()
        self._integral = [0.0, 0.0]
        self._last_error = [0.0, 0.0]
        self._output = [0.0, 0.0]
    
    def update(self, target: Tuple[float, float], dt: float) -> Tuple[float, float]:
        """Update PID controller."""
        kp = self.get_param("kp")
        ki = self.get_param("ki")
        kd = self.get_param("kd")
        integral_limit = self.get_param("integral_limit")
        smoothing = self.get_param("output_smoothing")
        
        px, py = self.state.position
        tx, ty = target
        
        outputs = []
        
        for i, (current, target_val) in enumerate([(px, tx), (py, ty)]):
            # Calculate error
            error = target_val - current
            
            # Proportional term
            p_term = kp * error
            
            # Integral term with anti-windup
            self._integral[i] += error * dt
            self._integral[i] = self.clamp(self._integral[i], -integral_limit, integral_limit)
            i_term = ki * self._integral[i]
            
            # Derivative term
            if dt > 0:
                d_term = kd * (error - self._last_error[i]) / dt
            else:
                d_term = 0
            self._last_error[i] = error
            
            # Calculate output
            output = p_term + i_term + d_term
            
            # Apply smoothing
            if smoothing > 0:
                output = smoothing * self._output[i] + (1 - smoothing) * output
            self._output[i] = output
            
            # Integrate output as velocity to get position
            new_pos = current + output * dt
            outputs.append(self.clamp(new_pos))
        
        self.state.position = tuple(outputs)
        self.state.target = target
        
        return self.state.position


class AdaptivePIDModel(PhysicsModel):
    """
    Adaptive PID that adjusts gains based on error magnitude.
    
    Larger errors get more aggressive response, small errors get gentle tracking.
    
    Good for: Fast response to large changes, precise fine control
    """
    
    name = "adaptive_pid"
    description = "Adaptive PID with error-dependent gain scaling"
    
    @property
    def default_params(self) -> Dict[str, Any]:
        return {
            "base_kp": 8.0,
            "base_ki": 0.3,
            "base_kd": 1.5,
            "error_gain_scale": 2.0,    # How much to scale gains with error
            "min_gain_multiplier": 0.3,  # Minimum gain multiplier for small errors
            "integral_limit": 1.0,
        }
    
    @property
    def param_ranges(self) -> Dict[str, Tuple[float, float, float]]:
        return {
            "base_kp": (0.1, 30.0, 0.1),
            "base_ki": (0.0, 3.0, 0.05),
            "base_kd": (0.0, 8.0, 0.1),
            "error_gain_scale": (0.5, 5.0, 0.1),
            "min_gain_multiplier": (0.1, 1.0, 0.05),
            "integral_limit": (0.1, 5.0, 0.1),
        }
    
    def __init__(self):
        super().__init__()
        self._params = self.default_params.copy()
        self._integral = [0.0, 0.0]
        self._last_error = [0.0, 0.0]
    
    def reset(self):
        """Reset state."""
        super().reset()
        self._integral = [0.0, 0.0]
        self._last_error = [0.0, 0.0]
    
    def update(self, target: Tuple[float, float], dt: float) -> Tuple[float, float]:
        """Update adaptive PID."""
        base_kp = self.get_param("base_kp")
        base_ki = self.get_param("base_ki")
        base_kd = self.get_param("base_kd")
        error_scale = self.get_param("error_gain_scale")
        min_mult = self.get_param("min_gain_multiplier")
        integral_limit = self.get_param("integral_limit")
        
        px, py = self.state.position
        tx, ty = target
        
        # Calculate total error for gain scaling
        total_error = math.sqrt((tx - px) ** 2 + (ty - py) ** 2)
        
        # Scale gains based on error (larger error = higher gains)
        gain_mult = min_mult + (1 - min_mult) * min(1.0, total_error * error_scale)
        
        kp = base_kp * gain_mult
        ki = base_ki * gain_mult
        kd = base_kd * gain_mult
        
        outputs = []
        
        for i, (current, target_val) in enumerate([(px, tx), (py, ty)]):
            error = target_val - current
            
            # PID terms
            p_term = kp * error
            
            self._integral[i] += error * dt
            self._integral[i] = self.clamp(self._integral[i], -integral_limit, integral_limit)
            i_term = ki * self._integral[i]
            
            if dt > 0:
                d_term = kd * (error - self._last_error[i]) / dt
            else:
                d_term = 0
            self._last_error[i] = error
            
            output = p_term + i_term + d_term
            new_pos = current + output * dt
            outputs.append(self.clamp(new_pos))
        
        self.state.position = tuple(outputs)
        self.state.target = target
        
        return self.state.position
