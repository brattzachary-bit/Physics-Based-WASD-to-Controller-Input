"""
Spring-damper physics model.
Simulates a spring-mass-damper system for smooth, responsive analog input.
"""

import math
from typing import Tuple, Dict, Any

from .base import PhysicsModel


class SpringModel(PhysicsModel):
    """
    Spring-damper model using Hooke's law with damping.
    
    F = -k*x - c*v
    
    Where:
        k = stiffness (spring constant)
        c = damping coefficient
        x = displacement from target
        v = velocity
    
    Good for: Responsive feel with natural oscillation control
    """
    
    name = "spring"
    description = "Spring-damper system with natural bounce and smooth response"
    
    @property
    def default_params(self) -> Dict[str, Any]:
        return {
            "stiffness": 80.0,      # Spring constant (higher = snappier)
            "damping": 12.0,        # Damping (higher = less oscillation)
            "mass": 1.0,            # Mass (higher = more momentum)
        }
    
    @property
    def param_ranges(self) -> Dict[str, Tuple[float, float, float]]:
        return {
            "stiffness": (10.0, 200.0, 1.0),
            "damping": (1.0, 30.0, 0.5),
            "mass": (0.1, 5.0, 0.1),
        }
    
    def __init__(self):
        super().__init__()
        self._params = self.default_params.copy()
    
    def update(self, target: Tuple[float, float], dt: float) -> Tuple[float, float]:
        """Update spring physics simulation."""
        stiffness = self.get_param("stiffness")
        damping = self.get_param("damping")
        mass = self.get_param("mass")
        
        # Current state
        px, py = self.state.position
        vx, vy = self.state.velocity
        tx, ty = target
        
        # Calculate spring force: F = -k * (pos - target) - c * velocity
        # Acceleration = F / mass
        
        # X axis
        dx = px - tx
        fx = -stiffness * dx - damping * vx
        ax = fx / mass
        
        # Y axis
        dy = py - ty
        fy = -stiffness * dy - damping * vy
        ay = fy / mass
        
        # Integrate velocity
        vx += ax * dt
        vy += ay * dt
        
        # Integrate position
        px += vx * dt
        py += vy * dt
        
        # Clamp to valid range
        px = self.clamp(px)
        py = self.clamp(py)
        
        # Update state
        self.state.position = (px, py)
        self.state.velocity = (vx, vy)
        self.state.target = target
        
        return self.state.position


class CriticallyDampedSpring(PhysicsModel):
    """
    Critically damped spring - reaches target as fast as possible without oscillation.
    
    Uses exact solution for critically damped harmonic oscillator.
    
    Good for: Precise control without any overshoot
    """
    
    name = "critical"
    description = "Critically damped spring - fast response, no overshoot"
    
    @property
    def default_params(self) -> Dict[str, Any]:
        return {
            "speed": 15.0,  # How fast to reach target (natural frequency)
        }
    
    @property
    def param_ranges(self) -> Dict[str, Tuple[float, float, float]]:
        return {
            "speed": (1.0, 50.0, 0.5),
        }
    
    def __init__(self):
        super().__init__()
        self._params = self.default_params.copy()
        self._time_at_target = {"x": 0.0, "y": 0.0}
        self._last_target = (0.0, 0.0)
    
    def update(self, target: Tuple[float, float], dt: float) -> Tuple[float, float]:
        """Update critically damped spring."""
        omega = self.get_param("speed")  # Natural frequency
        
        px, py = self.state.position
        vx, vy = self.state.velocity
        tx, ty = target
        
        # Check for target changes
        if target != self._last_target:
            self._time_at_target = {"x": 0.0, "y": 0.0}
            self._last_target = target
        
        # Critical damping: damping = 2 * sqrt(stiffness * mass)
        # For unit mass: damping = 2 * omega
        
        def critically_damped_step(pos, vel, target_pos, omega, dt):
            """Single axis critically damped update."""
            x = pos - target_pos
            
            # Critically damped: x(t) = (A + B*t) * e^(-omega*t)
            # Using velocity verlet-like integration
            
            exp_term = math.exp(-omega * dt)
            
            # New position approaches target exponentially
            new_x = (x + (vel + omega * x) * dt) * exp_term
            new_vel = (vel - omega * (vel + omega * x) * dt) * exp_term
            
            return target_pos + new_x, new_vel
        
        px, vx = critically_damped_step(px, vx, tx, omega, dt)
        py, vy = critically_damped_step(py, vy, ty, omega, dt)
        
        # Snap to target if very close
        if abs(px - tx) < 0.001 and abs(vx) < 0.001:
            px, vx = tx, 0.0
        if abs(py - ty) < 0.001 and abs(vy) < 0.001:
            py, vy = ty, 0.0
        
        px = self.clamp(px)
        py = self.clamp(py)
        
        self.state.position = (px, py)
        self.state.velocity = (vx, vy)
        self.state.target = target
        
        return self.state.position
