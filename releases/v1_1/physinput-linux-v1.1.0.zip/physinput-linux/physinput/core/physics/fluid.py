"""
Fluid dynamics physics models.
Simulates movement through viscous fluids and smooth interpolation.
"""

import math
from typing import Tuple, Dict, Any

from .base import PhysicsModel


class FluidModel(PhysicsModel):
    """
    Fluid dynamics model - movement through viscous medium.
    
    Simulates pushing through a fluid with viscous drag.
    Higher viscosity = more resistance, smoother movement.
    
    Good for: Underwater feel, smooth camera-like movement
    """
    
    name = "fluid"
    description = "Viscous fluid dynamics for smooth, flowing movement"
    
    @property
    def default_params(self) -> Dict[str, Any]:
        return {
            "viscosity": 5.0,    # Resistance to movement
            "inertia": 0.8,      # How much momentum is retained
            "force": 10.0,       # Force applied towards target
            "turbulence": 0.0,   # Random perturbation (0-1)
        }
    
    @property
    def param_ranges(self) -> Dict[str, Tuple[float, float, float]]:
        return {
            "viscosity": (0.5, 20.0, 0.5),
            "inertia": (0.0, 0.99, 0.01),
            "force": (1.0, 30.0, 0.5),
            "turbulence": (0.0, 0.5, 0.01),
        }
    
    def __init__(self):
        super().__init__()
        self._params = self.default_params.copy()
        self._turbulence_phase = 0.0
    
    def update(self, target: Tuple[float, float], dt: float) -> Tuple[float, float]:
        """Update fluid physics."""
        viscosity = self.get_param("viscosity")
        inertia = self.get_param("inertia")
        force = self.get_param("force")
        turbulence = self.get_param("turbulence")
        
        px, py = self.state.position
        vx, vy = self.state.velocity
        tx, ty = target
        
        # Direction to target
        dx = tx - px
        dy = ty - py
        
        # Apply force towards target
        fx = dx * force
        fy = dy * force
        
        # Viscous drag (proportional to velocity)
        fx -= vx * viscosity
        fy -= vy * viscosity
        
        # Optional turbulence
        if turbulence > 0:
            self._turbulence_phase += dt * 3.0
            turb_x = math.sin(self._turbulence_phase * 2.1) * turbulence
            turb_y = math.cos(self._turbulence_phase * 1.7) * turbulence
            fx += turb_x
            fy += turb_y
        
        # Update velocity with inertia
        vx = vx * inertia + fx * dt
        vy = vy * inertia + fy * dt
        
        # Update position
        px += vx * dt
        py += vy * dt
        
        # Clamp
        px = self.clamp(px)
        py = self.clamp(py)
        
        self.state.position = (px, py)
        self.state.velocity = (vx, vy)
        self.state.target = target
        
        return self.state.position


class SmoothDampModel(PhysicsModel):
    """
    Smooth damp interpolation (similar to Unity's SmoothDamp).
    
    Critically damped spring-like behavior with configurable smooth time.
    
    Good for: Camera follow, UI animations, predictable smoothing
    """
    
    name = "smoothdamp"
    description = "Smooth interpolation with configurable response time"
    
    @property
    def default_params(self) -> Dict[str, Any]:
        return {
            "smooth_time": 0.1,     # Time to reach target (approximately)
            "max_speed": 10.0,      # Maximum movement speed
        }
    
    @property
    def param_ranges(self) -> Dict[str, Tuple[float, float, float]]:
        return {
            "smooth_time": (0.01, 1.0, 0.01),
            "max_speed": (1.0, 50.0, 0.5),
        }
    
    def __init__(self):
        super().__init__()
        self._params = self.default_params.copy()
    
    def _smooth_damp(self, current: float, target: float, velocity: float, 
                     smooth_time: float, max_speed: float, dt: float) -> Tuple[float, float]:
        """
        Attempt to reach target smoothly.
        Returns (new_position, new_velocity)
        """
        # Based on Game Programming Gems 4, Chapter 1.10
        smooth_time = max(0.0001, smooth_time)
        omega = 2.0 / smooth_time
        
        x = omega * dt
        exp_term = 1.0 / (1.0 + x + 0.48 * x * x + 0.235 * x * x * x)
        
        delta = current - target
        original_target = target
        
        # Clamp maximum speed
        max_delta = max_speed * smooth_time
        delta = self.clamp(delta, -max_delta, max_delta)
        target = current - delta
        
        temp = (velocity + omega * delta) * dt
        velocity = (velocity - omega * temp) * exp_term
        
        output = target + (delta + temp) * exp_term
        
        # Prevent overshoot
        if (original_target - current > 0) == (output > original_target):
            output = original_target
            velocity = (output - original_target) / dt if dt > 0 else 0
        
        return output, velocity
    
    def update(self, target: Tuple[float, float], dt: float) -> Tuple[float, float]:
        """Update smooth damp."""
        smooth_time = self.get_param("smooth_time")
        max_speed = self.get_param("max_speed")
        
        px, py = self.state.position
        vx, vy = self.state.velocity
        tx, ty = target
        
        px, vx = self._smooth_damp(px, tx, vx, smooth_time, max_speed, dt)
        py, vy = self._smooth_damp(py, ty, vy, smooth_time, max_speed, dt)
        
        self.state.position = (px, py)
        self.state.velocity = (vx, vy)
        self.state.target = target
        
        return self.state.position


class ExponentialModel(PhysicsModel):
    """
    Simple exponential smoothing.
    
    Each frame, position moves a percentage towards target.
    Simple and predictable.
    
    Good for: Simple smoothing, UI elements
    """
    
    name = "exponential"
    description = "Simple exponential smoothing towards target"
    
    @property
    def default_params(self) -> Dict[str, Any]:
        return {
            "smoothing": 0.85,  # 0 = instant, 0.99 = very slow
        }
    
    @property
    def param_ranges(self) -> Dict[str, Tuple[float, float, float]]:
        return {
            "smoothing": (0.0, 0.99, 0.01),
        }
    
    def __init__(self):
        super().__init__()
        self._params = self.default_params.copy()
    
    def update(self, target: Tuple[float, float], dt: float) -> Tuple[float, float]:
        """Update exponential smoothing."""
        smoothing = self.get_param("smoothing")
        
        px, py = self.state.position
        tx, ty = target
        
        # Frame-rate independent smoothing
        factor = pow(smoothing, dt * 60)  # Normalized to 60fps
        
        px = px * factor + tx * (1 - factor)
        py = py * factor + ty * (1 - factor)
        
        # Snap to target if very close
        if abs(px - tx) < 0.001:
            px = tx
        if abs(py - ty) < 0.001:
            py = ty
        
        self.state.position = (px, py)
        self.state.target = target
        
        return self.state.position
