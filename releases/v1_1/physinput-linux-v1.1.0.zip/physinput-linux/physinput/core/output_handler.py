"""
Linux output handler - Creates virtual gamepad using uinput.
"""

import time
from typing import Optional
from dataclasses import dataclass, field
from typing import Dict

import evdev
from evdev import UInput, ecodes, AbsInfo


@dataclass
class GamepadState:
    """Current gamepad output state."""
    left_stick_x: float = 0.0
    left_stick_y: float = 0.0
    right_stick_x: float = 0.0
    right_stick_y: float = 0.0
    left_trigger: float = 0.0
    right_trigger: float = 0.0
    dpad_up: bool = False
    dpad_down: bool = False
    dpad_left: bool = False
    dpad_right: bool = False
    buttons: Dict[str, bool] = field(default_factory=dict)


class OutputHandler:
    """Creates and controls a virtual gamepad via uinput."""
    
    AXIS_MIN = -32768
    AXIS_MAX = 32767
    TRIGGER_MIN = 0
    TRIGGER_MAX = 255
    
    # Device identities
    IDENTITIES = {
        "xbox360": ("Microsoft X-Box 360 pad", 0x045E, 0x028E),
        "xboxone": ("Microsoft Xbox One Controller", 0x045E, 0x02DD),
        "ds4": ("Sony DualShock 4", 0x054C, 0x09CC),
        "dualsense": ("Sony DualSense", 0x054C, 0x0CE6),
        "generic": ("PhysInput Controller", 0x0001, 0x0001),
    }
    
    def __init__(self):
        self.state = GamepadState()
        self.device: Optional[UInput] = None
        self._identity = "xbox360"
    
    def set_identity(self, identity: str):
        """Set device identity (xbox360, xboxone, ds4, dualsense, generic)."""
        if identity in self.IDENTITIES:
            self._identity = identity
    
    def create_device(self) -> bool:
        """Create the virtual gamepad."""
        if self.device is not None:
            self.close_device()
        
        try:
            name, vendor, product = self.IDENTITIES.get(self._identity, self.IDENTITIES["xbox360"])
            
            buttons = [
                ecodes.BTN_SOUTH, ecodes.BTN_EAST, ecodes.BTN_NORTH, ecodes.BTN_WEST,
                ecodes.BTN_TL, ecodes.BTN_TR,
                ecodes.BTN_SELECT, ecodes.BTN_START, ecodes.BTN_MODE,
                ecodes.BTN_THUMBL, ecodes.BTN_THUMBR,
            ]
            
            axes = [
                (ecodes.ABS_X, AbsInfo(0, self.AXIS_MIN, self.AXIS_MAX, 16, 128, 0)),
                (ecodes.ABS_Y, AbsInfo(0, self.AXIS_MIN, self.AXIS_MAX, 16, 128, 0)),
                (ecodes.ABS_RX, AbsInfo(0, self.AXIS_MIN, self.AXIS_MAX, 16, 128, 0)),
                (ecodes.ABS_RY, AbsInfo(0, self.AXIS_MIN, self.AXIS_MAX, 16, 128, 0)),
                (ecodes.ABS_Z, AbsInfo(0, self.TRIGGER_MIN, self.TRIGGER_MAX, 0, 0, 0)),
                (ecodes.ABS_RZ, AbsInfo(0, self.TRIGGER_MIN, self.TRIGGER_MAX, 0, 0, 0)),
                (ecodes.ABS_HAT0X, AbsInfo(0, -1, 1, 0, 0, 0)),
                (ecodes.ABS_HAT0Y, AbsInfo(0, -1, 1, 0, 0, 0)),
            ]
            
            self.device = UInput(
                {ecodes.EV_KEY: buttons, ecodes.EV_ABS: axes},
                name=name, vendor=vendor, product=product,
                version=0x0110, bustype=ecodes.BUS_USB
            )
            
            time.sleep(0.1)
            return True
            
        except Exception as e:
            print(f"Failed to create virtual gamepad: {e}")
            self.device = None
            return False
    
    def close_device(self):
        """Close the virtual gamepad."""
        if self.device:
            try:
                self.set_left_stick(0, 0)
                self.set_right_stick(0, 0)
                self.set_triggers(0, 0)
                self.sync()
                self.device.close()
            except Exception:
                pass
            finally:
                self.device = None
    
    def _to_axis(self, v: float) -> int:
        return int(max(-1, min(1, v)) * self.AXIS_MAX)
    
    def _to_trigger(self, v: float) -> int:
        return int(max(0, min(1, v)) * self.TRIGGER_MAX)
    
    def set_left_stick(self, x: float, y: float):
        if not self.device: return
        self.state.left_stick_x, self.state.left_stick_y = x, y
        self.device.write(ecodes.EV_ABS, ecodes.ABS_X, self._to_axis(x))
        self.device.write(ecodes.EV_ABS, ecodes.ABS_Y, self._to_axis(-y))
    
    def set_right_stick(self, x: float, y: float):
        if not self.device: return
        self.state.right_stick_x, self.state.right_stick_y = x, y
        self.device.write(ecodes.EV_ABS, ecodes.ABS_RX, self._to_axis(x))
        self.device.write(ecodes.EV_ABS, ecodes.ABS_RY, self._to_axis(-y))
    
    def set_triggers(self, left: float, right: float):
        if not self.device: return
        self.state.left_trigger, self.state.right_trigger = left, right
        self.device.write(ecodes.EV_ABS, ecodes.ABS_Z, self._to_trigger(left))
        self.device.write(ecodes.EV_ABS, ecodes.ABS_RZ, self._to_trigger(right))
    
    def set_button(self, button: str, pressed: bool):
        if not self.device: return
        
        btn_map = {
            'BTN_SOUTH': ecodes.BTN_SOUTH, 'A': ecodes.BTN_SOUTH,
            'BTN_EAST': ecodes.BTN_EAST, 'B': ecodes.BTN_EAST,
            'BTN_WEST': ecodes.BTN_WEST, 'X': ecodes.BTN_WEST,
            'BTN_NORTH': ecodes.BTN_NORTH, 'Y': ecodes.BTN_NORTH,
            'BTN_TL': ecodes.BTN_TL, 'LB': ecodes.BTN_TL,
            'BTN_TR': ecodes.BTN_TR, 'RB': ecodes.BTN_TR,
            'BTN_SELECT': ecodes.BTN_SELECT, 'BACK': ecodes.BTN_SELECT,
            'BTN_START': ecodes.BTN_START, 'START': ecodes.BTN_START,
            'BTN_MODE': ecodes.BTN_MODE, 'GUIDE': ecodes.BTN_MODE,
            'BTN_THUMBL': ecodes.BTN_THUMBL, 'L3': ecodes.BTN_THUMBL,
            'BTN_THUMBR': ecodes.BTN_THUMBR, 'R3': ecodes.BTN_THUMBR,
        }
        
        b = button.upper()
        
        if b in ('LT', 'LEFT_TRIGGER'):
            self.state.left_trigger = 1.0 if pressed else 0.0
            self.device.write(ecodes.EV_ABS, ecodes.ABS_Z, self._to_trigger(self.state.left_trigger))
        elif b in ('RT', 'RIGHT_TRIGGER'):
            self.state.right_trigger = 1.0 if pressed else 0.0
            self.device.write(ecodes.EV_ABS, ecodes.ABS_RZ, self._to_trigger(self.state.right_trigger))
        elif b.startswith('DPAD_'):
            setattr(self.state, b.lower(), pressed)
            self._update_dpad()
        elif b in btn_map:
            self.state.buttons[b] = pressed
            self.device.write(ecodes.EV_KEY, btn_map[b], 1 if pressed else 0)
    
    def _update_dpad(self):
        hx = (-1 if self.state.dpad_left else 0) + (1 if self.state.dpad_right else 0)
        hy = (-1 if self.state.dpad_up else 0) + (1 if self.state.dpad_down else 0)
        self.device.write(ecodes.EV_ABS, ecodes.ABS_HAT0X, hx)
        self.device.write(ecodes.EV_ABS, ecodes.ABS_HAT0Y, hy)
    
    def sync(self):
        if self.device:
            self.device.syn()
    
    @property
    def is_active(self) -> bool:
        return self.device is not None
