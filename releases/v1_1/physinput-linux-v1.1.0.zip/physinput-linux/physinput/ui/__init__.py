"""
PhysInput UI Module.
"""

from .theme import COLORS, get_stylesheet, get_wizard_stylesheet, GraphColors, StickColors
from .main_window import MainWindow
from .wizard import SetupWizard

from .widgets import (
    StickWidget,
    DualStickWidget,
    GraphWidget,
    InputGraphsWidget,
    KeyCaptureButton,
    MovementKeyWidget,
    BindingEditorDialog,
)


__all__ = [
    # Theme
    'COLORS',
    'get_stylesheet',
    'get_wizard_stylesheet',
    'GraphColors',
    'StickColors',
    # Windows
    'MainWindow',
    'SetupWizard',
    # Widgets
    'StickWidget',
    'DualStickWidget',
    'GraphWidget',
    'InputGraphsWidget',
    'KeyCaptureButton',
    'MovementKeyWidget',
    'BindingEditorDialog',
]
