"""
Analog stick visualization widget.
"""

import math
from typing import Tuple, Optional

from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel
from PyQt6.QtCore import Qt, QPointF, QRectF, pyqtSignal
from PyQt6.QtGui import QPainter, QPen, QBrush, QColor, QRadialGradient, QPainterPath

from ..theme import COLORS, StickColors


class StickWidget(QWidget):
    """
    Visual representation of an analog stick.
    Shows current position with optional target indicator.
    """
    
    # Emitted when user clicks to set position (for testing)
    positionClicked = pyqtSignal(float, float)
    
    def __init__(self, title: str = "", parent=None):
        super().__init__(parent)
        
        self.title = title
        self._position = (0.0, 0.0)
        self._target = None
        self._deadzone = 0.0
        self._circular = False
        self._show_grid = True
        self._interactive = False
        
        # Colors
        self.colors = StickColors()
        
        # Size
        self.setMinimumSize(120, 140)
        self.setMaximumSize(200, 220)
        
        self._setup_ui()
    
    def _setup_ui(self):
        """Setup the widget UI."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(4)
        
        # Title label
        if self.title:
            self.title_label = QLabel(self.title)
            self.title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self.title_label.setStyleSheet(f"color: {COLORS['text_secondary']}; font-size: 11px;")
            layout.addWidget(self.title_label)
        
        # Coordinates label
        self.coords_label = QLabel("0.00, 0.00")
        self.coords_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.coords_label.setStyleSheet(f"color: {COLORS['text_muted']}; font-size: 10px; font-family: monospace;")
        layout.addWidget(self.coords_label)
        
        layout.addStretch()
    
    def set_position(self, x: float, y: float):
        """Set the current stick position."""
        self._position = (
            max(-1.0, min(1.0, x)),
            max(-1.0, min(1.0, y))
        )
        self.coords_label.setText(f"{self._position[0]:+.2f}, {self._position[1]:+.2f}")
        self.update()
    
    def set_target(self, x: Optional[float], y: Optional[float]):
        """Set the target position indicator."""
        if x is None or y is None:
            self._target = None
        else:
            self._target = (x, y)
        self.update()
    
    def set_deadzone(self, value: float):
        """Set deadzone radius to display."""
        self._deadzone = max(0, min(1, value))
        self.update()
    
    def set_circular(self, enabled: bool):
        """Set whether to show circular constraint."""
        self._circular = enabled
        self.update()
    
    def set_interactive(self, enabled: bool):
        """Enable/disable click interaction."""
        self._interactive = enabled
    
    @property
    def position(self) -> Tuple[float, float]:
        return self._position
    
    def paintEvent(self, event):
        """Paint the stick visualization."""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        # Calculate drawing area (square, centered)
        rect = self.rect()
        size = min(rect.width(), rect.height() - 40)  # Leave room for labels
        x_offset = (rect.width() - size) // 2
        y_offset = 30  # Below title
        
        center = QPointF(x_offset + size / 2, y_offset + size / 2)
        radius = (size - 10) / 2
        
        # Draw background
        painter.setPen(QPen(QColor(self.colors.border), 2))
        painter.setBrush(QBrush(QColor(self.colors.background)))
        
        if self._circular:
            painter.drawEllipse(center, radius, radius)
        else:
            painter.drawRoundedRect(
                int(center.x() - radius), int(center.y() - radius),
                int(radius * 2), int(radius * 2),
                8, 8
            )
        
        # Draw grid
        if self._show_grid:
            painter.setPen(QPen(QColor(self.colors.grid), 1))
            # Cross
            painter.drawLine(
                int(center.x()), int(center.y() - radius),
                int(center.x()), int(center.y() + radius)
            )
            painter.drawLine(
                int(center.x() - radius), int(center.y()),
                int(center.x() + radius), int(center.y())
            )
            # Circle at 50%
            painter.drawEllipse(center, radius * 0.5, radius * 0.5)
        
        # Draw deadzone
        if self._deadzone > 0:
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QBrush(QColor(self.colors.deadzone)))
            dz_radius = radius * self._deadzone
            painter.drawEllipse(center, dz_radius, dz_radius)
        
        # Draw target indicator
        if self._target:
            tx = center.x() + self._target[0] * radius
            ty = center.y() - self._target[1] * radius  # Y inverted
            
            painter.setPen(QPen(QColor(COLORS['text_muted']), 1, Qt.PenStyle.DashLine))
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.drawEllipse(QPointF(tx, ty), 6, 6)
        
        # Draw position dot
        px = center.x() + self._position[0] * radius
        py = center.y() - self._position[1] * radius  # Y inverted
        
        # Gradient for 3D effect
        gradient = QRadialGradient(px - 2, py - 2, 10)
        
        # Color based on magnitude
        magnitude = math.sqrt(self._position[0]**2 + self._position[1]**2)
        if magnitude > 0.1:
            gradient.setColorAt(0, QColor(self.colors.dot_active).lighter(130))
            gradient.setColorAt(1, QColor(self.colors.dot_active))
        else:
            gradient.setColorAt(0, QColor(self.colors.dot).lighter(130))
            gradient.setColorAt(1, QColor(self.colors.dot))
        
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QBrush(gradient))
        painter.drawEllipse(QPointF(px, py), 8, 8)
        
        # Draw line from center to dot
        if magnitude > 0.05:
            painter.setPen(QPen(QColor(self.colors.dot), 2))
            painter.drawLine(center, QPointF(px, py))
    
    def mousePressEvent(self, event):
        """Handle mouse click for interactive mode."""
        if not self._interactive:
            return
        
        # Calculate position from click
        rect = self.rect()
        size = min(rect.width(), rect.height() - 40)
        x_offset = (rect.width() - size) // 2
        y_offset = 30
        
        center_x = x_offset + size / 2
        center_y = y_offset + size / 2
        radius = (size - 10) / 2
        
        x = (event.position().x() - center_x) / radius
        y = -(event.position().y() - center_y) / radius  # Y inverted
        
        # Clamp to valid range
        x = max(-1, min(1, x))
        y = max(-1, min(1, y))
        
        if self._circular:
            magnitude = math.sqrt(x*x + y*y)
            if magnitude > 1:
                x /= magnitude
                y /= magnitude
        
        self.positionClicked.emit(x, y)


class DualStickWidget(QWidget):
    """
    Widget showing both left and right sticks side by side.
    """
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        
        from PyQt6.QtWidgets import QHBoxLayout
        sticks_layout = QHBoxLayout()
        sticks_layout.setSpacing(16)
        
        self.left_stick = StickWidget("Left Stick")
        self.right_stick = StickWidget("Right Stick")
        
        sticks_layout.addWidget(self.left_stick)
        sticks_layout.addWidget(self.right_stick)
        
        layout.addLayout(sticks_layout)
    
    def set_left_position(self, x: float, y: float):
        self.left_stick.set_position(x, y)
    
    def set_right_position(self, x: float, y: float):
        self.right_stick.set_position(x, y)
    
    def set_positions(self, left: Tuple[float, float], right: Tuple[float, float]):
        self.left_stick.set_position(*left)
        self.right_stick.set_position(*right)
