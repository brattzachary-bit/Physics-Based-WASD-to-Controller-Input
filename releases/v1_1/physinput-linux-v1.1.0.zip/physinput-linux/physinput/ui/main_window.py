"""
Main application window for PhysInput.
"""

import sys
import math
from typing import Optional

from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QTabWidget,
    QPushButton, QLabel, QFrame, QSlider, QComboBox, QCheckBox,
    QDoubleSpinBox, QSpinBox, QGroupBox, QScrollArea, QSplitter,
    QListWidget, QListWidgetItem, QMessageBox, QFileDialog,
    QApplication, QSizePolicy
)
from PyQt6.QtCore import Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QFont, QIcon, QCloseEvent

from .theme import COLORS, get_stylesheet
from .widgets import (
    DualStickWidget, InputGraphsWidget, 
    MovementKeyWidget, KeyCaptureButton, BindingEditorDialog
)
from .wizard import SetupWizard
from ..core import (
    Config, Engine, load_config, save_config,
    list_profiles, load_profile, save_profile, delete_profile,
    PHYSICS_MODELS, list_models, DEVICE_IDENTITIES
)


class StatusBar(QFrame):
    """Custom status bar with engine status and FPS."""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self.setProperty("class", "card")
        self.setFixedHeight(40)
        
        layout = QHBoxLayout(self)
        layout.setContentsMargins(16, 0, 16, 0)
        
        # Status indicator
        self.status_dot = QLabel("●")
        self.status_dot.setStyleSheet(f"color: {COLORS['text_muted']}; font-size: 16px;")
        layout.addWidget(self.status_dot)
        
        self.status_label = QLabel("Stopped")
        self.status_label.setStyleSheet(f"color: {COLORS['text_secondary']};")
        layout.addWidget(self.status_label)
        
        layout.addStretch()
        
        # FPS counter
        self.fps_label = QLabel("-- FPS")
        self.fps_label.setStyleSheet(f"color: {COLORS['text_muted']}; font-family: monospace;")
        layout.addWidget(self.fps_label)
        
        # Latency
        self.latency_label = QLabel("-- ms")
        self.latency_label.setStyleSheet(f"color: {COLORS['text_muted']}; font-family: monospace;")
        layout.addWidget(self.latency_label)
    
    def set_running(self, running: bool, enabled: bool = True):
        """Update status display."""
        if running and enabled:
            self.status_dot.setStyleSheet(f"color: {COLORS['success']}; font-size: 16px;")
            self.status_label.setText("Active")
            self.status_label.setStyleSheet(f"color: {COLORS['success']};")
        elif running and not enabled:
            self.status_dot.setStyleSheet(f"color: {COLORS['warning']}; font-size: 16px;")
            self.status_label.setText("Paused")
            self.status_label.setStyleSheet(f"color: {COLORS['warning']};")
        else:
            self.status_dot.setStyleSheet(f"color: {COLORS['text_muted']}; font-size: 16px;")
            self.status_label.setText("Stopped")
            self.status_label.setStyleSheet(f"color: {COLORS['text_secondary']};")
    
    def update_stats(self, fps: float, latency_ms: float):
        """Update performance stats."""
        self.fps_label.setText(f"{fps:.0f} FPS")
        self.latency_label.setText(f"{latency_ms:.1f} ms")


class ControlPanel(QFrame):
    """Main control panel with start/stop and quick settings."""
    
    startClicked = pyqtSignal()
    stopClicked = pyqtSignal()
    toggleClicked = pyqtSignal()
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self.setProperty("class", "card")
        
        layout = QVBoxLayout(self)
        layout.setSpacing(16)
        
        # Title
        title = QLabel("PhysInput")
        title.setStyleSheet(f"""
            font-size: 24px;
            font-weight: 700;
            color: {COLORS['text_primary']};
        """)
        layout.addWidget(title)
        
        # Start/Stop buttons
        btn_layout = QHBoxLayout()
        
        self.start_btn = QPushButton("Start")
        self.start_btn.setProperty("class", "success")
        self.start_btn.setMinimumHeight(44)
        self.start_btn.clicked.connect(self.startClicked)
        btn_layout.addWidget(self.start_btn)
        
        self.stop_btn = QPushButton("Stop")
        self.stop_btn.setProperty("class", "danger")
        self.stop_btn.setMinimumHeight(44)
        self.stop_btn.setEnabled(False)
        self.stop_btn.clicked.connect(self.stopClicked)
        btn_layout.addWidget(self.stop_btn)
        
        layout.addLayout(btn_layout)
        
        # Toggle button
        self.toggle_btn = QPushButton("Toggle (Pause)")
        self.toggle_btn.setMinimumHeight(36)
        self.toggle_btn.setEnabled(False)
        self.toggle_btn.clicked.connect(self.toggleClicked)
        layout.addWidget(self.toggle_btn)
        
        # Hotkey reminder
        self.hotkey_label = QLabel("Hotkey: Pause")
        self.hotkey_label.setStyleSheet(f"color: {COLORS['text_muted']}; font-size: 11px;")
        self.hotkey_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.hotkey_label)
    
    def set_running(self, running: bool):
        """Update button states."""
        self.start_btn.setEnabled(not running)
        self.stop_btn.setEnabled(running)
        self.toggle_btn.setEnabled(running)
    
    def set_hotkey(self, key: str):
        """Update hotkey display."""
        self.hotkey_label.setText(f"Hotkey: {key.upper()}")


class PhysicsPanel(QWidget):
    """Physics settings panel."""
    
    paramChanged = pyqtSignal(str, float)
    modelChanged = pyqtSignal(str)
    
    def __init__(self, config: Config, parent=None):
        super().__init__(parent)
        self.config = config
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        
        # Scroll area
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        
        content = QWidget()
        content_layout = QVBoxLayout(content)
        content_layout.setSpacing(16)
        
        # Model selection
        model_group = QGroupBox("Physics Model")
        model_layout = QVBoxLayout(model_group)
        
        self.model_combo = QComboBox()
        models = list_models()
        for model_id, description in models.items():
            self.model_combo.addItem(f"{model_id.title()} - {description}", model_id)
            if model_id == config.physics.model:
                self.model_combo.setCurrentIndex(self.model_combo.count() - 1)
        
        self.model_combo.currentIndexChanged.connect(self._on_model_changed)
        model_layout.addWidget(self.model_combo)
        
        content_layout.addWidget(model_group)
        
        # Parameters group
        params_group = QGroupBox("Parameters")
        params_layout = QVBoxLayout(params_group)
        
        self.param_widgets = {}
        
        # Spring parameters
        self._add_param(params_layout, "stiffness", "Stiffness", 10, 200, 
                       config.physics.stiffness, "Higher = snappier response")
        self._add_param(params_layout, "damping", "Damping", 1, 30,
                       config.physics.damping, "Higher = less oscillation")
        self._add_param(params_layout, "mass", "Mass", 0.1, 5,
                       config.physics.mass, "Higher = more momentum", decimals=1)
        
        content_layout.addWidget(params_group)
        
        # Return behavior
        return_group = QGroupBox("Return to Center")
        return_layout = QVBoxLayout(return_group)
        
        self._add_param(return_layout, "left_stick_return_time", "Left Stick", 0, 1,
                       config.physics.left_stick_return_time, "0 = instant", decimals=2)
        self._add_param(return_layout, "right_stick_return_time", "Right Stick", 0, 1,
                       config.physics.right_stick_return_time, "0 = instant", decimals=2)
        
        self.circular_check = QCheckBox("Circular constraint (limit to circle)")
        self.circular_check.setChecked(config.physics.circular_constraint)
        self.circular_check.stateChanged.connect(
            lambda s: self._emit_param("circular_constraint", 1.0 if s else 0.0)
        )
        return_layout.addWidget(self.circular_check)
        
        content_layout.addWidget(return_group)
        
        content_layout.addStretch()
        
        scroll.setWidget(content)
        layout.addWidget(scroll)
    
    def _add_param(self, layout, name: str, label: str, min_val: float, max_val: float,
                   default: float, tooltip: str = "", decimals: int = 0):
        """Add a parameter slider."""
        row = QHBoxLayout()
        
        lbl = QLabel(label)
        lbl.setMinimumWidth(100)
        if tooltip:
            lbl.setToolTip(tooltip)
        row.addWidget(lbl)
        
        if decimals > 0:
            spin = QDoubleSpinBox()
            spin.setDecimals(decimals)
            spin.setSingleStep(0.1 if decimals == 1 else 0.01)
        else:
            spin = QSpinBox()
        
        spin.setRange(int(min_val * (10 ** decimals)), int(max_val * (10 ** decimals)))
        spin.setValue(int(default * (10 ** decimals)) if decimals > 0 else int(default))
        spin.setMinimumWidth(80)
        
        if decimals > 0:
            spin.valueChanged.connect(lambda v, n=name: self._emit_param(n, v))
        else:
            spin.valueChanged.connect(lambda v, n=name: self._emit_param(n, float(v)))
        
        row.addWidget(spin)
        
        self.param_widgets[name] = spin
        layout.addLayout(row)
    
    def _emit_param(self, name: str, value: float):
        """Emit parameter change."""
        self.paramChanged.emit(name, value)
    
    def _on_model_changed(self, index):
        """Handle model change."""
        model = self.model_combo.currentData()
        self.modelChanged.emit(model)


class MousePanel(QWidget):
    """Mouse/right stick settings panel."""
    
    settingChanged = pyqtSignal(str, object)
    
    def __init__(self, config: Config, parent=None):
        super().__init__(parent)
        self.config = config
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        
        content = QWidget()
        content_layout = QVBoxLayout(content)
        content_layout.setSpacing(16)
        
        # Enable/disable
        self.enable_check = QCheckBox("Enable mouse → right stick")
        self.enable_check.setChecked(config.mouse.enabled)
        self.enable_check.stateChanged.connect(
            lambda s: self.settingChanged.emit("enabled", bool(s))
        )
        content_layout.addWidget(self.enable_check)
        
        # Sensitivity
        sens_group = QGroupBox("Sensitivity")
        sens_layout = QVBoxLayout(sens_group)
        
        sens_row = QHBoxLayout()
        sens_row.addWidget(QLabel("Sensitivity"))
        self.sens_spin = QDoubleSpinBox()
        self.sens_spin.setRange(0.1, 5.0)
        self.sens_spin.setSingleStep(0.1)
        self.sens_spin.setValue(config.mouse.sensitivity)
        self.sens_spin.valueChanged.connect(
            lambda v: self.settingChanged.emit("sensitivity", v)
        )
        sens_row.addWidget(self.sens_spin)
        sens_layout.addLayout(sens_row)
        
        content_layout.addWidget(sens_group)
        
        # Velocity mode
        vel_group = QGroupBox("Velocity Mode")
        vel_layout = QVBoxLayout(vel_group)
        
        self.vel_check = QCheckBox("Use velocity-based mapping")
        self.vel_check.setChecked(config.mouse.velocity_mode)
        self.vel_check.setToolTip("Mouse speed determines stick deflection")
        self.vel_check.stateChanged.connect(
            lambda s: self.settingChanged.emit("velocity_mode", bool(s))
        )
        vel_layout.addWidget(self.vel_check)
        
        thresh_row = QHBoxLayout()
        thresh_row.addWidget(QLabel("Max threshold"))
        self.thresh_spin = QSpinBox()
        self.thresh_spin.setRange(500, 10000)
        self.thresh_spin.setSingleStep(100)
        self.thresh_spin.setValue(int(config.mouse.velocity_threshold))
        self.thresh_spin.setToolTip("Mouse speed for full stick deflection")
        self.thresh_spin.valueChanged.connect(
            lambda v: self.settingChanged.emit("velocity_threshold", float(v))
        )
        thresh_row.addWidget(self.thresh_spin)
        vel_layout.addLayout(thresh_row)
        
        min_thresh_row = QHBoxLayout()
        min_thresh_row.addWidget(QLabel("Min threshold"))
        self.min_thresh_spin = QSpinBox()
        self.min_thresh_spin.setRange(0, 1000)
        self.min_thresh_spin.setSingleStep(10)
        self.min_thresh_spin.setValue(int(config.mouse.velocity_min_threshold))
        self.min_thresh_spin.setToolTip("Deadzone for mouse movement")
        self.min_thresh_spin.valueChanged.connect(
            lambda v: self.settingChanged.emit("velocity_min_threshold", float(v))
        )
        min_thresh_row.addWidget(self.min_thresh_spin)
        vel_layout.addLayout(min_thresh_row)
        
        curve_row = QHBoxLayout()
        curve_row.addWidget(QLabel("Acceleration curve"))
        self.curve_spin = QDoubleSpinBox()
        self.curve_spin.setRange(0.1, 3.0)
        self.curve_spin.setSingleStep(0.1)
        self.curve_spin.setValue(config.mouse.acceleration_curve)
        self.curve_spin.setToolTip("1.0 = linear, <1 = more sensitive at low speeds")
        self.curve_spin.valueChanged.connect(
            lambda v: self.settingChanged.emit("acceleration_curve", v)
        )
        curve_row.addWidget(self.curve_spin)
        vel_layout.addLayout(curve_row)
        
        content_layout.addWidget(vel_group)
        
        # Smoothing
        smooth_group = QGroupBox("Smoothing")
        smooth_layout = QVBoxLayout(smooth_group)
        
        self.smooth_check = QCheckBox("Enable smoothing")
        self.smooth_check.setChecked(config.mouse.smoothing_enabled)
        self.smooth_check.stateChanged.connect(
            lambda s: self.settingChanged.emit("smoothing_enabled", bool(s))
        )
        smooth_layout.addWidget(self.smooth_check)
        
        frames_row = QHBoxLayout()
        frames_row.addWidget(QLabel("Frames to average"))
        self.frames_spin = QSpinBox()
        self.frames_spin.setRange(1, 10)
        self.frames_spin.setValue(config.mouse.smoothing_frames)
        self.frames_spin.valueChanged.connect(
            lambda v: self.settingChanged.emit("smoothing_frames", v)
        )
        frames_row.addWidget(self.frames_spin)
        smooth_layout.addLayout(frames_row)
        
        content_layout.addWidget(smooth_group)
        
        # Inversion
        invert_group = QGroupBox("Inversion")
        invert_layout = QHBoxLayout(invert_group)
        
        self.invert_x = QCheckBox("Invert X")
        self.invert_x.setChecked(config.mouse.invert_x)
        self.invert_x.stateChanged.connect(
            lambda s: self.settingChanged.emit("invert_x", bool(s))
        )
        invert_layout.addWidget(self.invert_x)
        
        self.invert_y = QCheckBox("Invert Y")
        self.invert_y.setChecked(config.mouse.invert_y)
        self.invert_y.stateChanged.connect(
            lambda s: self.settingChanged.emit("invert_y", bool(s))
        )
        invert_layout.addWidget(self.invert_y)
        
        content_layout.addWidget(invert_group)
        
        content_layout.addStretch()
        
        scroll.setWidget(content)
        layout.addWidget(scroll)


class BindingsPanel(QWidget):
    """Button bindings editor panel."""
    
    bindingsChanged = pyqtSignal()
    
    def __init__(self, config: Config, parent=None):
        super().__init__(parent)
        self.config = config
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(16)
        
        # Movement keys
        self.movement_widget = MovementKeyWidget()
        self.movement_widget.set_keys(
            config.movement_keys.up,
            config.movement_keys.down,
            config.movement_keys.left,
            config.movement_keys.right
        )
        self.movement_widget.keyChanged.connect(self._on_movement_changed)
        layout.addWidget(self.movement_widget)
        
        # Button bindings
        bindings_group = QGroupBox("Button Bindings")
        bindings_layout = QVBoxLayout(bindings_group)
        
        self.bindings_list = QListWidget()
        self.bindings_list.setMinimumHeight(150)
        self._refresh_bindings()
        bindings_layout.addWidget(self.bindings_list)
        
        btn_layout = QHBoxLayout()
        
        add_btn = QPushButton("Add")
        add_btn.clicked.connect(self._add_binding)
        btn_layout.addWidget(add_btn)
        
        edit_btn = QPushButton("Edit")
        edit_btn.clicked.connect(self._edit_binding)
        btn_layout.addWidget(edit_btn)
        
        remove_btn = QPushButton("Remove")
        remove_btn.clicked.connect(self._remove_binding)
        btn_layout.addWidget(remove_btn)
        
        bindings_layout.addLayout(btn_layout)
        layout.addWidget(bindings_group)
        
        layout.addStretch()
    
    def _on_movement_changed(self, direction: str, key: str):
        """Handle movement key change."""
        setattr(self.config.movement_keys, direction, key)
        self.bindingsChanged.emit()
    
    def _refresh_bindings(self):
        """Refresh bindings list."""
        self.bindings_list.clear()
        
        for key, button in self.config.button_bindings.items():
            item = QListWidgetItem(f"{key.upper()}  →  {button}")
            item.setData(Qt.ItemDataRole.UserRole, key)
            self.bindings_list.addItem(item)
    
    def _add_binding(self):
        """Add a new binding."""
        dialog = BindingEditorDialog(parent=self)
        if dialog.exec():
            key, button = dialog.get_binding()
            if key:
                self.config.button_bindings[key] = button
                self._refresh_bindings()
                self.bindingsChanged.emit()
    
    def _edit_binding(self):
        """Edit selected binding."""
        item = self.bindings_list.currentItem()
        if not item:
            return
        
        key = item.data(Qt.ItemDataRole.UserRole)
        button = self.config.button_bindings.get(key, "")
        
        dialog = BindingEditorDialog(key, button, parent=self)
        if dialog.exec():
            new_key, new_button = dialog.get_binding()
            if new_key:
                # Remove old
                self.config.button_bindings.pop(key, None)
                # Add new
                self.config.button_bindings[new_key] = new_button
                self._refresh_bindings()
                self.bindingsChanged.emit()
    
    def _remove_binding(self):
        """Remove selected binding."""
        item = self.bindings_list.currentItem()
        if not item:
            return
        
        key = item.data(Qt.ItemDataRole.UserRole)
        self.config.button_bindings.pop(key, None)
        self._refresh_bindings()
        self.bindingsChanged.emit()


class ProfilesPanel(QWidget):
    """Profile management panel."""
    
    profileLoaded = pyqtSignal(Config)
    
    def __init__(self, config: Config, parent=None):
        super().__init__(parent)
        self.config = config
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(16)
        
        # Profiles list
        profiles_group = QGroupBox("Saved Profiles")
        profiles_layout = QVBoxLayout(profiles_group)
        
        self.profiles_list = QListWidget()
        self._refresh_profiles()
        profiles_layout.addWidget(self.profiles_list)
        
        btn_layout = QHBoxLayout()
        
        load_btn = QPushButton("Load")
        load_btn.clicked.connect(self._load_profile)
        btn_layout.addWidget(load_btn)
        
        save_btn = QPushButton("Save As...")
        save_btn.clicked.connect(self._save_profile)
        btn_layout.addWidget(save_btn)
        
        delete_btn = QPushButton("Delete")
        delete_btn.clicked.connect(self._delete_profile)
        btn_layout.addWidget(delete_btn)
        
        profiles_layout.addLayout(btn_layout)
        layout.addWidget(profiles_group)
        
        # Import/Export
        io_group = QGroupBox("Import/Export")
        io_layout = QHBoxLayout(io_group)
        
        import_btn = QPushButton("Import...")
        import_btn.clicked.connect(self._import_profile)
        io_layout.addWidget(import_btn)
        
        export_btn = QPushButton("Export...")
        export_btn.clicked.connect(self._export_profile)
        io_layout.addWidget(export_btn)
        
        layout.addWidget(io_group)
        
        layout.addStretch()
    
    def _refresh_profiles(self):
        """Refresh profiles list."""
        self.profiles_list.clear()
        for name in list_profiles():
            self.profiles_list.addItem(name)
    
    def _load_profile(self):
        """Load selected profile."""
        item = self.profiles_list.currentItem()
        if not item:
            return
        
        profile = load_profile(item.text())
        if profile:
            self.profileLoaded.emit(profile)
    
    def _save_profile(self):
        """Save current config as profile."""
        from PyQt6.QtWidgets import QInputDialog
        
        name, ok = QInputDialog.getText(self, "Save Profile", "Profile name:")
        if ok and name:
            save_profile(name, self.config)
            self._refresh_profiles()
    
    def _delete_profile(self):
        """Delete selected profile."""
        item = self.profiles_list.currentItem()
        if not item:
            return
        
        reply = QMessageBox.question(
            self, "Delete Profile",
            f"Delete profile '{item.text()}'?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        
        if reply == QMessageBox.StandardButton.Yes:
            delete_profile(item.text())
            self._refresh_profiles()
    
    def _import_profile(self):
        """Import profile from file."""
        from ..core import import_profile
        
        filepath, _ = QFileDialog.getOpenFileName(
            self, "Import Profile", "", "JSON Files (*.json)"
        )
        
        if filepath:
            profile = import_profile(filepath)
            if profile:
                self.profileLoaded.emit(profile)
            else:
                QMessageBox.warning(self, "Import Failed", "Could not import profile.")
    
    def _export_profile(self):
        """Export current config to file."""
        from ..core import export_profile
        
        filepath, _ = QFileDialog.getSaveFileName(
            self, "Export Profile", "physinput_profile.json", "JSON Files (*.json)"
        )
        
        if filepath:
            if export_profile(self.config, filepath):
                QMessageBox.information(self, "Export Complete", "Profile exported successfully.")
            else:
                QMessageBox.warning(self, "Export Failed", "Could not export profile.")


class MainWindow(QMainWindow):
    """Main PhysInput application window."""
    
    def __init__(self):
        super().__init__()
        
        self.setWindowTitle("PhysInput")
        self.setMinimumSize(900, 650)
        
        # Load config
        self.config = load_config()
        
        # Create engine
        self.engine = Engine(self.config)
        self.engine.on_state_change = self._on_engine_state_change
        
        # Apply theme
        self.setStyleSheet(get_stylesheet())
        
        # Setup UI
        self._setup_ui()
        
        # Setup update timer
        self.update_timer = QTimer()
        self.update_timer.timeout.connect(self._update_display)
        self.update_timer.start(16)  # ~60 FPS
        
        # Check first run
        if not self.config.first_run_complete:
            QTimer.singleShot(100, self._show_wizard)
    
    def _setup_ui(self):
        """Setup the main UI."""
        central = QWidget()
        self.setCentralWidget(central)
        
        main_layout = QHBoxLayout(central)
        main_layout.setSpacing(16)
        main_layout.setContentsMargins(16, 16, 16, 16)
        
        # Left sidebar
        left_panel = QVBoxLayout()
        left_panel.setSpacing(16)
        
        # Control panel
        self.control_panel = ControlPanel()
        self.control_panel.startClicked.connect(self._start_engine)
        self.control_panel.stopClicked.connect(self._stop_engine)
        self.control_panel.toggleClicked.connect(self._toggle_engine)
        self.control_panel.set_hotkey(self.config.hotkey)
        left_panel.addWidget(self.control_panel)
        
        # Stick visualizers
        self.sticks_widget = DualStickWidget()
        left_panel.addWidget(self.sticks_widget)
        
        # Status bar
        self.status_bar = StatusBar()
        left_panel.addWidget(self.status_bar)
        
        left_panel.addStretch()
        
        left_widget = QWidget()
        left_widget.setLayout(left_panel)
        left_widget.setFixedWidth(300)
        main_layout.addWidget(left_widget)
        
        # Right panel with tabs
        right_panel = QVBoxLayout()
        right_panel.setSpacing(0)
        
        # Tab widget
        self.tabs = QTabWidget()
        
        # Visualization tab
        viz_widget = QWidget()
        viz_layout = QVBoxLayout(viz_widget)
        viz_layout.setContentsMargins(16, 16, 16, 16)
        
        self.graphs_widget = InputGraphsWidget(max_points=self.config.ui.graph_history)
        viz_layout.addWidget(self.graphs_widget)
        
        self.tabs.addTab(viz_widget, "Visualization")
        
        # Physics tab
        self.physics_panel = PhysicsPanel(self.config)
        self.physics_panel.paramChanged.connect(self._on_physics_param_changed)
        self.physics_panel.modelChanged.connect(self._on_physics_model_changed)
        self.tabs.addTab(self.physics_panel, "Physics")
        
        # Mouse tab
        self.mouse_panel = MousePanel(self.config)
        self.mouse_panel.settingChanged.connect(self._on_mouse_setting_changed)
        self.tabs.addTab(self.mouse_panel, "Mouse")
        
        # Bindings tab
        self.bindings_panel = BindingsPanel(self.config)
        self.bindings_panel.bindingsChanged.connect(self._on_bindings_changed)
        self.tabs.addTab(self.bindings_panel, "Bindings")
        
        # Profiles tab
        self.profiles_panel = ProfilesPanel(self.config)
        self.profiles_panel.profileLoaded.connect(self._load_profile)
        self.tabs.addTab(self.profiles_panel, "Profiles")
        
        right_panel.addWidget(self.tabs)
        main_layout.addLayout(right_panel, 1)
    
    def _show_wizard(self):
        """Show the setup wizard."""
        wizard = SetupWizard(self.config, self)
        wizard.setupComplete.connect(self._on_wizard_complete)
        wizard.exec()
    
    def _on_wizard_complete(self, config: Config):
        """Handle wizard completion."""
        self.config = config
        self.engine.config = config
        save_config(config)
        
        # Update UI
        self.control_panel.set_hotkey(config.hotkey)
        self._refresh_ui()
    
    def _refresh_ui(self):
        """Refresh UI from config."""
        self.bindings_panel.movement_widget.set_keys(
            self.config.movement_keys.up,
            self.config.movement_keys.down,
            self.config.movement_keys.left,
            self.config.movement_keys.right
        )
        self.bindings_panel._refresh_bindings()
    
    def _start_engine(self):
        """Start the engine."""
        if self.engine.start():
            self.control_panel.set_running(True)
            self.status_bar.set_running(True, True)
        else:
            QMessageBox.critical(
                self, "Error",
                "Failed to start PhysInput. Make sure you have permission to access input devices.\n\n"
                "Try running with sudo or add your user to the 'input' group."
            )
    
    def _stop_engine(self):
        """Stop the engine."""
        self.engine.stop()
        self.control_panel.set_running(False)
        self.status_bar.set_running(False)
        
        # Reset visualizers
        self.sticks_widget.set_positions((0, 0), (0, 0))
        self.graphs_widget.clear()
    
    def _toggle_engine(self):
        """Toggle engine enabled state."""
        self.engine.toggle()
        self.status_bar.set_running(self.engine.is_running, self.engine.is_enabled)
    
    def _on_engine_state_change(self, running: bool):
        """Handle engine state change (from hotkey)."""
        self.status_bar.set_running(self.engine.is_running, self.engine.is_enabled)
    
    def _update_display(self):
        """Update display with current values."""
        if not self.engine.is_running:
            return
        
        # Update stick positions
        self.sticks_widget.set_positions(
            self.engine.left_stick,
            self.engine.right_stick
        )
        
        # Update graphs
        velocity = math.sqrt(
            self.engine._mouse_velocity[0]**2 + 
            self.engine._mouse_velocity[1]**2
        ) if hasattr(self.engine, '_mouse_velocity') else 0
        
        self.graphs_widget.update_values(
            self.engine.left_stick,
            self.engine.right_stick,
            velocity
        )
        
        # Update stats
        self.status_bar.update_stats(
            self.engine.stats.fps,
            self.engine.stats.frame_time_ms
        )
    
    def _on_physics_param_changed(self, name: str, value: float):
        """Handle physics parameter change."""
        if name == "circular_constraint":
            self.config.physics.circular_constraint = bool(value)
        else:
            self.engine.set_physics_param(name, value)
    
    def _on_physics_model_changed(self, model: str):
        """Handle physics model change."""
        self.engine.set_physics_model(model)
    
    def _on_mouse_setting_changed(self, name: str, value):
        """Handle mouse setting change."""
        setattr(self.config.mouse, name, value)
    
    def _on_bindings_changed(self):
        """Handle binding changes."""
        # Update engine with new movement keys
        keys = self.bindings_panel.movement_widget.get_keys()
        for direction, key in keys.items():
            self.engine.set_movement_key(direction, key)
    
    def _load_profile(self, config: Config):
        """Load a profile."""
        self.config = config
        self.engine.config = config
        self._refresh_ui()
        
        # Restart engine if running
        if self.engine.is_running:
            self._stop_engine()
            self._start_engine()
    
    def closeEvent(self, event: QCloseEvent):
        """Handle window close."""
        # Stop engine
        if self.engine.is_running:
            self.engine.stop()
        
        # Save config
        save_config(self.config)
        
        event.accept()
