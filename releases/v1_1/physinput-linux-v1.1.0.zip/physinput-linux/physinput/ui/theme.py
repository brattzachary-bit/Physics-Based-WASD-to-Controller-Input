"""
Theme system for PhysInput UI.
Modern dark theme with accent colors.
"""

from dataclasses import dataclass
from typing import Dict

# Color palette
COLORS = {
    # Base colors
    'bg_darkest': '#0a0a0f',
    'bg_darker': '#0f0f18', 
    'bg_dark': '#151520',
    'bg_medium': '#1a1a28',
    'bg_light': '#222235',
    'bg_lighter': '#2a2a42',
    'bg_hover': '#333350',
    
    # Text colors
    'text_primary': '#e8e8f0',
    'text_secondary': '#a0a0b8',
    'text_muted': '#606078',
    'text_disabled': '#404055',
    
    # Accent colors
    'accent_primary': '#6366f1',      # Indigo
    'accent_secondary': '#818cf8',
    'accent_hover': '#4f46e5',
    'accent_pressed': '#4338ca',
    
    # Status colors
    'success': '#22c55e',
    'success_bg': '#166534',
    'warning': '#f59e0b',
    'warning_bg': '#92400e',
    'error': '#ef4444',
    'error_bg': '#991b1b',
    'info': '#3b82f6',
    
    # Interactive elements
    'button_bg': '#2a2a42',
    'button_hover': '#363655',
    'button_pressed': '#404065',
    'input_bg': '#12121a',
    'input_border': '#333350',
    'input_focus': '#6366f1',
    
    # Graph/visualization colors
    'graph_line': '#6366f1',
    'graph_fill': 'rgba(99, 102, 241, 0.2)',
    'graph_grid': '#252535',
    'stick_bg': '#12121a',
    'stick_border': '#333350',
    'stick_dot': '#6366f1',
    'stick_dot_active': '#22c55e',
    
    # Borders
    'border_subtle': '#252535',
    'border_default': '#333350',
    'border_strong': '#444465',
}


def get_stylesheet() -> str:
    """Generate the main application stylesheet."""
    c = COLORS
    
    return f"""
    /* ========== Global ========== */
    QWidget {{
        background-color: {c['bg_dark']};
        color: {c['text_primary']};
        font-family: 'Inter', 'Segoe UI', 'Ubuntu', sans-serif;
        font-size: 13px;
    }}
    
    QMainWindow {{
        background-color: {c['bg_darkest']};
    }}
    
    /* ========== Labels ========== */
    QLabel {{
        background: transparent;
        padding: 2px;
    }}
    
    QLabel[class="heading"] {{
        font-size: 16px;
        font-weight: 600;
        color: {c['text_primary']};
    }}
    
    QLabel[class="subheading"] {{
        font-size: 14px;
        font-weight: 500;
        color: {c['text_secondary']};
    }}
    
    QLabel[class="muted"] {{
        color: {c['text_muted']};
        font-size: 12px;
    }}
    
    /* ========== Buttons ========== */
    QPushButton {{
        background-color: {c['button_bg']};
        border: 1px solid {c['border_default']};
        border-radius: 6px;
        padding: 8px 16px;
        font-weight: 500;
        min-height: 20px;
    }}
    
    QPushButton:hover {{
        background-color: {c['button_hover']};
        border-color: {c['border_strong']};
    }}
    
    QPushButton:pressed {{
        background-color: {c['button_pressed']};
    }}
    
    QPushButton:disabled {{
        background-color: {c['bg_medium']};
        color: {c['text_disabled']};
        border-color: {c['border_subtle']};
    }}
    
    QPushButton[class="primary"] {{
        background-color: {c['accent_primary']};
        border-color: {c['accent_primary']};
        color: white;
    }}
    
    QPushButton[class="primary"]:hover {{
        background-color: {c['accent_hover']};
        border-color: {c['accent_hover']};
    }}
    
    QPushButton[class="primary"]:pressed {{
        background-color: {c['accent_pressed']};
    }}
    
    QPushButton[class="success"] {{
        background-color: {c['success']};
        border-color: {c['success']};
        color: white;
    }}
    
    QPushButton[class="danger"] {{
        background-color: {c['error']};
        border-color: {c['error']};
        color: white;
    }}
    
    /* ========== Input Fields ========== */
    QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox {{
        background-color: {c['input_bg']};
        border: 1px solid {c['input_border']};
        border-radius: 6px;
        padding: 8px 12px;
        selection-background-color: {c['accent_primary']};
    }}
    
    QLineEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus, QComboBox:focus {{
        border-color: {c['input_focus']};
    }}
    
    QLineEdit:disabled, QSpinBox:disabled, QDoubleSpinBox:disabled {{
        background-color: {c['bg_medium']};
        color: {c['text_disabled']};
    }}
    
    QComboBox::drop-down {{
        border: none;
        padding-right: 8px;
    }}
    
    QComboBox::down-arrow {{
        image: none;
        border-left: 5px solid transparent;
        border-right: 5px solid transparent;
        border-top: 6px solid {c['text_secondary']};
        margin-right: 8px;
    }}
    
    QComboBox QAbstractItemView {{
        background-color: {c['bg_medium']};
        border: 1px solid {c['border_default']};
        border-radius: 6px;
        selection-background-color: {c['accent_primary']};
        padding: 4px;
    }}
    
    /* ========== Sliders ========== */
    QSlider::groove:horizontal {{
        background: {c['bg_lighter']};
        height: 6px;
        border-radius: 3px;
    }}
    
    QSlider::handle:horizontal {{
        background: {c['accent_primary']};
        width: 16px;
        height: 16px;
        margin: -5px 0;
        border-radius: 8px;
    }}
    
    QSlider::handle:horizontal:hover {{
        background: {c['accent_secondary']};
    }}
    
    QSlider::sub-page:horizontal {{
        background: {c['accent_primary']};
        border-radius: 3px;
    }}
    
    /* ========== Checkboxes ========== */
    QCheckBox {{
        spacing: 8px;
    }}
    
    QCheckBox::indicator {{
        width: 18px;
        height: 18px;
        border-radius: 4px;
        border: 2px solid {c['border_default']};
        background: {c['input_bg']};
    }}
    
    QCheckBox::indicator:checked {{
        background: {c['accent_primary']};
        border-color: {c['accent_primary']};
    }}
    
    QCheckBox::indicator:hover {{
        border-color: {c['accent_secondary']};
    }}
    
    /* ========== Tab Widget ========== */
    QTabWidget::pane {{
        background: {c['bg_dark']};
        border: 1px solid {c['border_subtle']};
        border-radius: 8px;
        margin-top: -1px;
    }}
    
    QTabBar::tab {{
        background: {c['bg_medium']};
        border: 1px solid {c['border_subtle']};
        border-bottom: none;
        border-top-left-radius: 6px;
        border-top-right-radius: 6px;
        padding: 10px 20px;
        margin-right: 2px;
        color: {c['text_secondary']};
    }}
    
    QTabBar::tab:selected {{
        background: {c['bg_dark']};
        color: {c['text_primary']};
        border-bottom: 2px solid {c['accent_primary']};
    }}
    
    QTabBar::tab:hover:!selected {{
        background: {c['bg_light']};
    }}
    
    /* ========== Scroll Areas ========== */
    QScrollArea {{
        background: transparent;
        border: none;
    }}
    
    QScrollBar:vertical {{
        background: {c['bg_darker']};
        width: 10px;
        border-radius: 5px;
        margin: 0;
    }}
    
    QScrollBar::handle:vertical {{
        background: {c['bg_lighter']};
        border-radius: 5px;
        min-height: 30px;
    }}
    
    QScrollBar::handle:vertical:hover {{
        background: {c['bg_hover']};
    }}
    
    QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
        height: 0;
    }}
    
    QScrollBar:horizontal {{
        background: {c['bg_darker']};
        height: 10px;
        border-radius: 5px;
    }}
    
    QScrollBar::handle:horizontal {{
        background: {c['bg_lighter']};
        border-radius: 5px;
        min-width: 30px;
    }}
    
    /* ========== Group Box ========== */
    QGroupBox {{
        background: {c['bg_medium']};
        border: 1px solid {c['border_subtle']};
        border-radius: 8px;
        margin-top: 16px;
        padding: 16px;
        padding-top: 24px;
        font-weight: 500;
    }}
    
    QGroupBox::title {{
        subcontrol-origin: margin;
        subcontrol-position: top left;
        left: 12px;
        top: 4px;
        padding: 0 8px;
        background: {c['bg_medium']};
        color: {c['text_secondary']};
    }}
    
    /* ========== List Widget ========== */
    QListWidget {{
        background: {c['input_bg']};
        border: 1px solid {c['input_border']};
        border-radius: 6px;
        padding: 4px;
        outline: none;
    }}
    
    QListWidget::item {{
        padding: 8px 12px;
        border-radius: 4px;
    }}
    
    QListWidget::item:selected {{
        background: {c['accent_primary']};
    }}
    
    QListWidget::item:hover:!selected {{
        background: {c['bg_hover']};
    }}
    
    /* ========== Tool Tips ========== */
    QToolTip {{
        background: {c['bg_light']};
        color: {c['text_primary']};
        border: 1px solid {c['border_default']};
        border-radius: 4px;
        padding: 6px 10px;
    }}
    
    /* ========== Frames ========== */
    QFrame[class="card"] {{
        background: {c['bg_medium']};
        border: 1px solid {c['border_subtle']};
        border-radius: 8px;
    }}
    
    QFrame[class="separator"] {{
        background: {c['border_subtle']};
        max-height: 1px;
    }}
    
    /* ========== Status Indicators ========== */
    QLabel[class="status-active"] {{
        color: {c['success']};
        font-weight: 600;
    }}
    
    QLabel[class="status-inactive"] {{
        color: {c['text_muted']};
    }}
    
    QLabel[class="status-warning"] {{
        color: {c['warning']};
    }}
    
    QLabel[class="status-error"] {{
        color: {c['error']};
    }}
    
    /* ========== Message Box ========== */
    QMessageBox {{
        background: {c['bg_dark']};
    }}
    
    QMessageBox QLabel {{
        color: {c['text_primary']};
    }}
    
    /* ========== Dialog ========== */
    QDialog {{
        background: {c['bg_dark']};
    }}
    """


def get_wizard_stylesheet() -> str:
    """Stylesheet additions for the setup wizard."""
    c = COLORS
    
    return get_stylesheet() + f"""
    QWizard {{
        background: {c['bg_darkest']};
    }}
    
    QWizardPage {{
        background: {c['bg_dark']};
    }}
    
    QWizard QLabel#title {{
        font-size: 24px;
        font-weight: 700;
        color: {c['text_primary']};
        margin-bottom: 8px;
    }}
    
    QWizard QLabel#subtitle {{
        font-size: 14px;
        color: {c['text_secondary']};
        margin-bottom: 24px;
    }}
    """


@dataclass
class GraphColors:
    """Colors for graphs and visualizations."""
    background: str = COLORS['bg_darkest']
    grid: str = COLORS['graph_grid']
    line: str = COLORS['graph_line']
    fill: str = COLORS['graph_fill']
    text: str = COLORS['text_secondary']
    axis: str = COLORS['border_default']


@dataclass
class StickColors:
    """Colors for stick visualizers."""
    background: str = COLORS['stick_bg']
    border: str = COLORS['stick_border']
    grid: str = COLORS['graph_grid']
    dot: str = COLORS['stick_dot']
    dot_active: str = COLORS['stick_dot_active']
    deadzone: str = 'rgba(99, 102, 241, 0.15)'
