"""
PhysInput - Physics-Based Analog Input for Linux
A professional accessibility tool that converts keyboard/mouse input to smooth analog joystick output.

Copyright (c) 2025 PhysInput Contributors
Licensed under the MIT License
"""

__version__ = "1.1.0"
__app_name__ = "PhysInput"
__platform__ = "linux"

from pathlib import Path

# Application paths
CONFIG_DIR = Path.home() / ".config" / "physinput"
PROFILES_DIR = CONFIG_DIR / "profiles"
CONFIG_FILE = CONFIG_DIR / "config.json"
PRESETS_DIR = CONFIG_DIR / "presets"

# Ensure directories exist
CONFIG_DIR.mkdir(parents=True, exist_ok=True)
PROFILES_DIR.mkdir(parents=True, exist_ok=True)
PRESETS_DIR.mkdir(parents=True, exist_ok=True)
