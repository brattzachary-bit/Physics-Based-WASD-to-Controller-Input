#!/bin/bash
set -e
echo "PhysInput Linux Installer"
echo "========================="

pip3 install evdev PyQt6 --break-system-packages
pip3 install -e . --break-system-packages

if ! groups | grep -q '\binput\b'; then
    echo "Adding user to input group..."
    sudo usermod -aG input $USER
    echo "⚠️  LOG OUT AND BACK IN for changes to take effect!"
fi

echo "Done! Run: physinput"
