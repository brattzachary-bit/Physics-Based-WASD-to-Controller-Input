# PhysInput for Linux

Physics-based analog input converter - transforms keyboard/mouse into smooth gamepad output.

## ⚠️ Anti-Cheat Notice

PhysInput creates a virtual gamepad. Some anti-cheat software may block virtual devices.
Intended for accessibility and single-player games.

## Installation

```bash
# Install dependencies
pip install evdev PyQt6 --break-system-packages

# Add user to input group (required)
sudo usermod -aG input $USER
# Then LOG OUT and LOG BACK IN

# Install PhysInput
pip install -e .

# Run
physinput
```

## Requirements

- Python 3.10+
- evdev (kernel input access)
- PyQt6 (GUI)
- User must be in `input` group

## Features

- 9 physics models (spring, critical, momentum, fluid, etc.)
- Mouse to right stick with velocity mapping
- Full button binding
- Profile system
- Real-time visualization

## Usage

```bash
physinput           # Start GUI
physinput --check   # Check system requirements
physinput --profile "fps"  # Load a profile
```

## License

MIT License
